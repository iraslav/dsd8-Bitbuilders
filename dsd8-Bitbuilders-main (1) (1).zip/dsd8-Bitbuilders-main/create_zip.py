import os
import shutil
import zipfile
from pathlib import Path

source_dir = Path("c:/Users/shifa/Downloads/dsd8-Bitbuilders-main/dsd8-Bitbuilders-main")
zip_output = Path("c:/Users/shifa/Downloads/dsd8-Bitbuilders-main/DSD8_Processor_With_Timer.zip")
downloads_zip = Path("c:/Users/shifa/Downloads/DSD8_Processor_With_Timer.zip")

flutter_code = """import 'dart:async';
import 'package:flutter/material.dart';

class TimerComponent extends StatefulWidget {
  final int initialSeconds;
  final VoidCallback? onTimerComplete;

  const TimerComponent({
    super.key,
    this.initialSeconds = 60,
    this.onTimerComplete,
  });

  @override
  State<TimerComponent> createState() => _TimerComponentState();
}

class _TimerComponentState extends State<TimerComponent> {
  late int _remainingSeconds;
  Timer? _timer;
  bool _isRunning = false;

  @override
  void initState() {
    super.initState();
    _remainingSeconds = widget.initialSeconds;
  }

  void _startTimer() {
    if (_isRunning) return;
    setState(() => _isRunning = true);
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_remainingSeconds > 0) {
        setState(() => _remainingSeconds--);
      } else {
        _stopTimer();
        widget.onTimerComplete?.call();
      }
    });
  }

  void _stopTimer() {
    _timer?.cancel();
    setState(() => _isRunning = false);
  }

  void _resetTimer() {
    _stopTimer();
    setState(() => _remainingSeconds = widget.initialSeconds);
  }

  String get _formattedTime {
    final minutes = (_remainingSeconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (_remainingSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              _formattedTime,
              style: const TextStyle(
                fontSize: 56,
                fontWeight: FontWeight.bold,
                fontFamily: 'monospace',
              ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  onPressed: _isRunning ? _stopTimer : _startTimer,
                  icon: Icon(_isRunning ? Icons.pause : Icons.play_arrow),
                  label: Text(_isRunning ? 'Pause' : 'Start'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _isRunning ? Colors.amber : Colors.green,
                    foregroundColor: Colors.white,
                  ),
                ),
                const SizedBox(width: 16),
                OutlinedButton.icon(
                  onPressed: _resetTimer,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Reset'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
"""

with zipfile.ZipFile(zip_output, "w", zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(source_dir):
        dirs[:] = [d for d in dirs if d not in ("build", ".git", ".venv", "__pycache__")]
        for f in files:
            if f.endswith((".vcd", ".vvp", ".out", "traces_ui.json", ".pyc")):
                continue
            fp = Path(root) / f
            arcname = Path("dsd8_processor") / fp.relative_to(source_dir)
            zf.write(fp, arcname)

    # Include Flutter timer component
    zf.writestr("flutter_timer_component/timer_component.dart", flutter_code)

# Also copy directly to Downloads folder
try:
    shutil.copyfile(zip_output, downloads_zip)
    print(f"Copied to {downloads_zip}")
except Exception as e:
    print(f"Could not copy to {downloads_zip}: {e}")

print(f"Zip created successfully at: {zip_output} ({zip_output.stat().st_size:,} bytes)")
