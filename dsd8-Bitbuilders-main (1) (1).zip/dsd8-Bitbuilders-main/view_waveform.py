#!/usr/bin/env python3
import os
import subprocess
import sys
from pathlib import Path

current_dir = Path(__file__).resolve().parent
inner_script = current_dir / "dsd8-Bitbuilders-main" / "scripts" / "view_waveform.py"
if not inner_script.exists():
    inner_script = current_dir / "scripts" / "view_waveform.py"

args = [sys.executable, str(inner_script)] + sys.argv[1:]
sys.exit(subprocess.run(args).returncode)
