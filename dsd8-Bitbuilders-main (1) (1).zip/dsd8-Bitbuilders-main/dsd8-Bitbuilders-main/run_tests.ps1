# PowerShell runner for DSD-8 Processor verification
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host " Running DSD-8 Unit Tests..." -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan
python scripts\run_unit_tests.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "`n[FAILED] Unit tests failed." -ForegroundColor Red
    exit $LASTEXITCODE
}

Write-Host "`n=======================================================" -ForegroundColor Cyan
Write-Host " Running DSD-8 Conformance Tests..." -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan
python scripts\run_conformance.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "`n[FAILED] Conformance tests failed." -ForegroundColor Red
    exit $LASTEXITCODE
}

Write-Host "`n[SUCCESS] All unit tests and conformance tests passed successfully!`n" -ForegroundColor Green
