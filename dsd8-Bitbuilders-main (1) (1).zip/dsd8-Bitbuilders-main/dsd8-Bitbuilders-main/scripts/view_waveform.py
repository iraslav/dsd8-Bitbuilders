#!/usr/bin/env python3
"""
view_waveform.py -- compile, simulate, and launch GTKWave to view CPU waveforms.
Usage:
    python scripts/view_waveform.py [program_name]
Example:
    python scripts/view_waveform.py sample01_multiply
    python scripts/view_waveform.py sample03_fibonacci
"""
import argparse
import os
import pathlib
import shutil
import subprocess
import sys

# Auto-detect Icarus Verilog and GTKWave on Windows
if sys.platform == "win32":
    for candidate in [r"C:\iverilog\bin", r"C:\iverilog\gtkwave\bin", r"C:\Program Files\iverilog\bin"]:
        if os.path.isdir(candidate) and candidate not in os.environ.get("PATH", ""):
            os.environ["PATH"] = candidate + os.pathsep + os.environ.get("PATH", "")

REPO_ROOT = pathlib.Path(__file__).resolve().parent.parent
RTL = REPO_ROOT / "rtl"
TB = REPO_ROOT / "tb" / "tb_dsd8.v"
PERIPHERALS = REPO_ROOT / "sim" / "peripherals.v"
TOOLS = REPO_ROOT / "tools"
TESTS_DIR = REPO_ROOT / "tests" / "conformance"
BUILD_DIR = REPO_ROOT / "build" / "conformance"

RTL_SOURCES = [
    "dsd8_cpu.v", "prog_counter.v", "instr_memory.v", "instr_decoder.v",
    "register_file.v", "alu.v", "flags_reg.v", "data_memory.v",
    "control_unit.v", "watchdog_timer.v", "io_bus.v",
]


def create_gtkw_file(gtkw_path, vcd_filename):
    content = f"""[*]
[*] GTKWave Analyzer Save File
[*]
[dumpfile] "{vcd_filename}"
[savefile] "{gtkw_path.name}"
[timestart] 0
[size] 1300 800
[pos] -1 -1
*-signals-
tb_dsd8.clk
tb_dsd8.rst_n
@28
tb_dsd8.imem_addr[8:0]
@20
tb_dsd8.imem_data[15:0]
@28
tb_dsd8.retire
tb_dsd8.retire_pc[8:0]
@20
tb_dsd8.retire_ir[15:0]
@28
tb_dsd8.retire_rf_we
tb_dsd8.retire_rf_addr[2:0]
@22
tb_dsd8.retire_rf_data[7:0]
@28
tb_dsd8.retire_flags[3:0]
@22
tb_dsd8.leds[7:0]
@28
tb_dsd8.io_bus_inst.wdt.ctrl_reg[1:0]
@22
tb_dsd8.io_bus_inst.wdt.down_count[7:0]
@28
tb_dsd8.io_bus_inst.wdt.presc_count[7:0]
tb_dsd8.io_bus_inst.wdt.expired
tb_dsd8.io_bus_inst.wdt.reset_req
tb_dsd8.halted
[pattern_trace] 1
[pattern_trace] 0
"""
    gtkw_path.write_text(content)


def main():
    parser = argparse.ArgumentParser(description="Generate and open GTKWave waveform")
    parser.add_argument("program", nargs="?", default="sample01_multiply",
                        help="Program to run (e.g. sample01_multiply, sample02_popcount, sample03_fibonacci)")
    args = parser.parse_args()

    prog_stem = args.program.replace(".asm", "").replace(".hex", "")
    asm_path = TESTS_DIR / f"{prog_stem}.asm"
    if not asm_path.exists():
        print(f"Error: Could not find {asm_path}")
        sys.exit(1)

    BUILD_DIR.mkdir(parents=True, exist_ok=True)
    hex_path = BUILD_DIR / f"{prog_stem}.hex"
    sim_bin = BUILD_DIR / f"{prog_stem}.vvp"
    vcd_path = REPO_ROOT / "cpu_waveform.vcd"
    gtkw_path = REPO_ROOT / "cpu_waveform.gtkw"
    program_hex_root = REPO_ROOT / "program.hex"

    # Step 1: Assemble
    print(f"[1/4] Assembling {asm_path.name}...")
    r = subprocess.run([sys.executable, str(TOOLS / "dsd8asm.py"), str(asm_path), "-o", str(hex_path)], capture_output=True, text=True)
    if r.returncode != 0:
        print(f"Assembler failed:\n{r.stderr}")
        sys.exit(1)

    shutil.copyfile(hex_path, program_hex_root)

    # Step 2: Compile
    print("[2/4] Compiling RTL with Icarus Verilog...")
    sources = [str(RTL / f) for f in RTL_SOURCES] + [str(PERIPHERALS), str(TB)]
    r = subprocess.run(["iverilog", "-g2005", "-o", str(sim_bin)] + sources, capture_output=True, text=True)
    if r.returncode != 0:
        program_hex_root.unlink(missing_ok=True)
        print(f"iverilog failed:\n{r.stderr}")
        sys.exit(1)

    # Step 3: Simulate with +vcd
    print("[3/4] Running simulation and generating waveform dump (cpu_waveform.vcd)...")
    r = subprocess.run(["vvp", str(sim_bin), "+vcd"], cwd=str(REPO_ROOT), capture_output=True, text=True)
    program_hex_root.unlink(missing_ok=True)
    if not vcd_path.exists():
        print(f"Simulation failed or VCD not generated:\n{r.stdout}\n{r.stderr}")
        sys.exit(1)

    print(f"      Waveform dump successfully generated: {vcd_path.name} ({vcd_path.stat().st_size:,} bytes)")

    # Also copy to root folder if running from root
    try:
        outer_root = REPO_ROOT.parent
        if outer_root != REPO_ROOT and (outer_root / "dsd8-Bitbuilders-main").exists():
            shutil.copyfile(vcd_path, outer_root / "cpu_waveform.vcd")
            shutil.copyfile(gtkw_path, outer_root / "cpu_waveform.gtkw")
    except Exception:
        pass

    # Step 4: Create GTKWave setup and launch
    create_gtkw_file(gtkw_path, vcd_path.name)
    gtkwave_exe = shutil.which("gtkwave")
    if not gtkwave_exe:
        # Check standard location
        candidate = r"C:\iverilog\gtkwave\bin\gtkwave.exe"
        if os.path.isfile(candidate):
            gtkwave_exe = candidate

    print("[4/4] Launching GTKWave GUI...")
    if gtkwave_exe:
        try:
            subprocess.Popen([gtkwave_exe, str(vcd_path), str(gtkw_path)], cwd=str(REPO_ROOT))
            print("      GTKWave window opened successfully!")
        except Exception as e:
            print(f"      Notice: Could not launch GUI automatically: {e}")
            print(f"      You can manually open it with: gtkwave {vcd_path} {gtkw_path}")
    else:
        print(f"      GTKWave executable not found in PATH. You can open {vcd_path} in your waveform viewer.")


if __name__ == "__main__":
    main()
