`ifndef DSD8_CPU_V
`define DSD8_CPU_V

module dsd8_cpu (
    input wire clk, input wire rst_n,
    output wire [8:0] imem_addr, input wire [15:0] imem_data,
    output wire [7:0] io_port, output wire [7:0] io_wdata,
    input wire [7:0] io_rdata, output wire io_rd, output wire io_wr,
    input wire io_ready, output wire halted, output wire retire,
    output wire [8:0] retire_pc, output wire [15:0] retire_ir,
    output wire retire_rf_we, output wire [2:0] retire_rf_addr,
    output wire [7:0] retire_rf_data, output wire retire_mem_we,
    output wire [7:0] retire_mem_addr, output wire [7:0] retire_mem_data,
    output wire [3:0] retire_flags
);
    reg [8:0] pc;
    reg [7:0] regs [0:7];
    reg [7:0] dmem [0:255];
    reg [3:0] flags;
    reg halted_r, halt_pending, retire_r, io_rd_r, io_wr_r;
    reg [7:0] io_port_r, io_wdata_r;
    reg [8:0] trace_pc;
    reg [15:0] trace_ir;
    reg trace_rf_we, trace_mem_we;
    reg [2:0] trace_rf_addr;
    reg [7:0] trace_rf_data, trace_mem_addr, trace_mem_data;
    reg [3:0] trace_flags;
    integer i;

    initial begin
        for (i = 0; i < 256; i = i + 1) dmem[i] = 8'h00;
    end

    assign imem_addr = pc;
    assign halted = halted_r;
    assign retire = retire_r;
    assign io_port = io_port_r;
    assign io_wdata = io_wdata_r;
    assign io_rd = io_rd_r;
    assign io_wr = io_wr_r;
    assign retire_pc = trace_pc;
    assign retire_ir = trace_ir;
    assign retire_rf_we = trace_rf_we;
    assign retire_rf_addr = trace_rf_addr;
    assign retire_rf_data = trace_rf_data;
    assign retire_mem_we = trace_mem_we;
    assign retire_mem_addr = trace_mem_addr;
    assign retire_mem_data = trace_mem_data;
    assign retire_flags = trace_flags;

    always @(*) begin
        io_port_r = imem_data[7:0];
        io_wdata_r = regs[imem_data[11:9]];
        io_rd_r = !halted_r && imem_data[15:12] == 4'hE && !imem_data[8];
        io_wr_r = !halted_r && imem_data[15:12] == 4'hE && imem_data[8];
    end

    always @(posedge clk) begin : execute
        reg [3:0] op;
        reg [2:0] rd, rs1, rs2, cond;
        reg [7:0] a, b, result, addr, value;
        reg [8:0] next_pc;
        reg carry, overflow, taken;

        if (!rst_n) begin
            pc <= 9'h000;
            flags <= 4'b0000;
            halted_r <= 1'b0;
            halt_pending <= 1'b0;
            retire_r <= 1'b0;
            trace_pc <= 9'h000;
            trace_ir <= 16'h0000;
            trace_rf_we <= 1'b0;
            trace_mem_we <= 1'b0;
            trace_rf_addr <= 3'b000;
            trace_rf_data <= 8'h00;
            trace_mem_addr <= 8'h00;
            trace_mem_data <= 8'h00;
            trace_flags <= 4'b0000;
            for (i = 0; i < 8; i = i + 1) regs[i] <= 8'h00;
        end else if (halt_pending) begin
            halted_r <= 1'b1;
            halt_pending <= 1'b0;
            retire_r <= 1'b0;
        end else if (!halted_r && (imem_data[15:12] != 4'hE || io_ready)) begin
            op = imem_data[15:12];
            rd = imem_data[11:9];
            rs1 = imem_data[8:6];
            rs2 = imem_data[5:3];
            cond = imem_data[11:9];
            a = regs[rs1];
            b = regs[rs2];
            result = 8'h00;
            next_pc = pc + 9'h001;
            carry = 1'b0;
            overflow = 1'b0;
            taken = 1'b0;

            trace_pc <= pc;
            trace_ir <= imem_data;
            trace_rf_we <= 1'b0;
            trace_rf_addr <= 3'b000;
            trace_rf_data <= 8'h00;
            trace_mem_we <= 1'b0;
            trace_mem_addr <= 8'h00;
            trace_mem_data <= 8'h00;

            case (op)
                4'h1: begin
                    result = imem_data[7:0];
                    regs[rd] <= result;
                    trace_rf_we <= 1'b1; trace_rf_addr <= rd; trace_rf_data <= result;
                end
                4'h2: begin
                    addr = regs[rs1]; value = dmem[addr];
                    regs[rd] <= value;
                    trace_rf_we <= 1'b1; trace_rf_addr <= rd; trace_rf_data <= value;
                end
                4'h3: begin
                    addr = regs[rs1]; value = regs[rd]; dmem[addr] <= value;
                    trace_mem_we <= 1'b1; trace_mem_addr <= addr; trace_mem_data <= value;
                end
                4'h4, 4'h5: begin
                    if (op == 4'h4) begin
                        result = a + b; carry = (a + b) > 8'hff;
                        overflow = (a[7] == b[7]) && (result[7] != a[7]);
                    end else begin
                        result = a - b; carry = (a >= b);
                        overflow = (a[7] != b[7]) && (result[7] != a[7]);
                    end
                    regs[rd] <= result;
                    flags <= {(result == 8'h00), result[7], carry, overflow};
                    trace_flags <= {(result == 8'h00), result[7], carry, overflow};
                    trace_rf_we <= 1'b1; trace_rf_addr <= rd; trace_rf_data <= result;
                end
                4'h6, 4'h7, 4'h8: begin
                    if (op == 4'h6) result = a & b;
                    else if (op == 4'h7) result = a | b;
                    else result = a ^ b;
                    regs[rd] <= result; flags <= {(result == 8'h00), result[7], 1'b0, 1'b0};
                    trace_flags <= {(result == 8'h00), result[7], 1'b0, 1'b0};
                    trace_rf_we <= 1'b1; trace_rf_addr <= rd; trace_rf_data <= result;
                end
                4'h9: begin
                    result = {a[6:0], 1'b0}; regs[rd] <= result;
                    flags <= {(result == 8'h00), result[7], a[7], 1'b0};
                    trace_flags <= {(result == 8'h00), result[7], a[7], 1'b0};
                    trace_rf_we <= 1'b1; trace_rf_addr <= rd; trace_rf_data <= result;
                end
                4'hA: begin
                    result = {1'b0, a[7:1]}; regs[rd] <= result;
                    flags <= {(result == 8'h00), result[7], a[0], 1'b0};
                    trace_flags <= {(result == 8'h00), result[7], a[0], 1'b0};
                    trace_rf_we <= 1'b1; trace_rf_addr <= rd; trace_rf_data <= result;
                end
                4'hB: begin
                    result = a - b; carry = (a >= b);
                    overflow = (a[7] != b[7]) && (result[7] != a[7]);
                    flags <= {(result == 8'h00), result[7], carry, overflow};
                    trace_flags <= {(result == 8'h00), result[7], carry, overflow};
                end
                4'hC: next_pc = imem_data[8:0];
                4'hD: begin
                    case (cond)
                        3'b000: taken = flags[3];
                        3'b001: taken = !flags[3];
                        3'b010: taken = flags[1];
                        3'b011: taken = !flags[1];
                        3'b100: taken = flags[2];
                        3'b101: taken = !flags[2];
                        3'b110: taken = flags[0];
                        default: taken = !flags[0];
                    endcase
                    if (taken) next_pc = imem_data[8:0];
                end
                4'hE: begin
                    if (!imem_data[8]) begin
                        value = io_rdata; regs[rd] <= value;
                        trace_rf_we <= 1'b1; trace_rf_addr <= rd; trace_rf_data <= value;
                    end
                end
                4'hF: halt_pending <= 1'b1;
                default: begin end
            endcase

            pc <= next_pc;
            if (op != 4'h4 && op != 4'h5 && op != 4'h6 && op != 4'h7 &&
                op != 4'h8 && op != 4'h9 && op != 4'hA && op != 4'hB)
                trace_flags <= flags;
            retire_r <= 1'b1;
        end else begin
            retire_r <= 1'b0;
        end
    end
endmodule

`endif
