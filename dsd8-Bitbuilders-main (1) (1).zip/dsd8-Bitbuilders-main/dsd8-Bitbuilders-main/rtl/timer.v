// timer.v -- synthesizable hardware timer peripheral for DSD-8
// Standard port map (Section 7.2):
//   Port 0x30: read current 8-bit timer count
//   Port 0x31: write timer control:
//              bit 0: enable (1 = start counting, 0 = pause)
//              bit 1: clear  (1 = reset count to 0x00)
//              bit [7:2]: reserved

module timer (
    input  wire       clk,
    input  wire       rst_n,

    // Bus interface (compatible with io_bus)
    input  wire [7:0] port,       // 0x30 = count, 0x31 = ctrl
    input  wire [7:0] wdata,
    output reg  [7:0] rdata,
    input  wire       rd,
    input  wire       wr,
    output wire       ready,

    // Direct hardware status outputs
    output wire [7:0] count,
    output wire       enabled,
    output reg        overflow    // pulses high on 8-bit wrap around (0xFF -> 0x00)
);

    reg [7:0] timer_count;
    reg       timer_enable;

    assign ready   = 1'b1;        // timer responds in 1 cycle without stall
    assign count   = timer_count;
    assign enabled = timer_enable;

    always @(posedge clk) begin
        if (!rst_n) begin
            timer_count  <= 8'h00;
            timer_enable <= 1'b0;
            overflow     <= 1'b0;
        end else begin
            overflow <= 1'b0;

            // Control register write (port 0x31)
            if (wr && port == 8'h31) begin
                timer_enable <= wdata[0];
                if (wdata[1]) begin
                    timer_count <= 8'h00;
                end
            end else if (timer_enable) begin
                timer_count <= timer_count + 8'h01;
                if (timer_count == 8'hFF) begin
                    overflow <= 1'b1;
                end
            end
        end
    end

    // Combinational bus read (port 0x30 = count, port 0x31 = status)
    always @(*) begin
        if (rd && port == 8'h30) begin
            rdata = timer_count;
        end else if (rd && port == 8'h31) begin
            rdata = {7'b0000000, timer_enable};
        end else begin
            rdata = 8'h00;
        end
    end

endmodule
