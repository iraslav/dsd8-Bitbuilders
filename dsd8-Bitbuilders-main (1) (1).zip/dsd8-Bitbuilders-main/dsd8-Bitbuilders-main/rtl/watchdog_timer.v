// watchdog_timer.v -- Synthesizable Watchdog Timer for DSD-8 Processor
//
// Purpose:
//   Monitors CPU execution and detects software hangs / deadlocks.
//   If software fails to "kick" (service) the watchdog within the configured
//   timeout window, the sticky expired flag is asserted (driving an external
//   indicator LED), and an optional reset request pulse is generated to reset
//   the CPU back to its initial boot vector.
//
// Register Map (IO Ports 0x50 - 0x55):
//   0x50: WD_CTRL   [R/W] - Bit 0: Enable (1=enabled, 0=disabled)
//                           Bit 1: Reset-on-expiry (1=assert reset_req, 0=flag only)
//   0x51: WD_RELOAD [R/W] - 8-bit counter reload value
//   0x52: WD_PRESC  [R/W] - 8-bit prescaler reload value
//   0x53: WD_KICK   [W]   - Write 0xA5 to service/kick the watchdog
//   0x54: WD_STATUS [R/W] - Bit 0: Expired flag (sticky, 1=timeout occurred)
//                           Bit 1: Enabled flag (reflects WD_CTRL[0])
//                           Writing any value clears the expired flag
//   0x55: WD_COUNT  [R]   - 8-bit current down-counter value
//
// Timeout Formula:
//   Timeout clock cycles = (WD_RELOAD + 1) * (WD_PRESC + 1)
//

`timescale 1ns/1ps

`ifndef WATCHDOG_TIMER_V
`define WATCHDOG_TIMER_V

module watchdog_timer (
    input  wire        clk,
    input  wire        rst_n,        // System synchronous active-low reset

    // ---- IO Bus Interface (Ports 0x50 - 0x55) ----
    input  wire [7:0]  io_port,
    input  wire [7:0]  io_wdata,
    output reg  [7:0]  io_rdata,
    input  wire        io_rd,
    input  wire        io_wr,
    output wire        io_ready,     // Always 1'b1 (single-cycle register access)

    // ---- Hardware Control / Status Outputs ----
    output wire        expired,      // Sticky expired indicator (drives LED)
    output wire        reset_req     // 1-cycle active-high pulse to reset CPU
);

    // Key required for valid kick operation
    localparam [7:0] KICK_KEY = 8'hA5;

    // Internal registers
    reg [1:0] ctrl_reg;        // [0]: enable, [1]: reset_on_expiry
    reg [7:0] reload_reg;      // Down-counter reload value
    reg [7:0] presc_reg;       // Prescaler reload value
    reg [7:0] down_count;      // Current down-counter value
    reg [7:0] presc_count;     // Current prescaler down-counter
    reg       expired_reg;     // Sticky expired flag
    reg       reset_req_reg;   // 1-cycle pulse reset request

    // Combinational outputs
    assign io_ready  = 1'b1;
    assign expired   = expired_reg;
    assign reset_req = reset_req_reg;

    // Combinational read decode
    always @(*) begin
        case (io_port)
            8'h50:   io_rdata = {6'b000000, ctrl_reg};
            8'h51:   io_rdata = reload_reg;
            8'h52:   io_rdata = presc_reg;
            8'h53:   io_rdata = 8'h00; // WD_KICK is write-only
            8'h54:   io_rdata = {6'b000000, ctrl_reg[0], expired_reg};
            8'h55:   io_rdata = down_count;
            default: io_rdata = 8'h00;
        endcase
    end

    // Detect valid kick: must write exactly KICK_KEY (0xA5) to port 0x53
    wire valid_kick = (io_wr && (io_port == 8'h53) && (io_wdata == KICK_KEY));

    // Sequential state logic
    always @(posedge clk) begin
        if (!rst_n) begin
            ctrl_reg      <= 2'b00;
            reload_reg    <= 8'h00;
            presc_reg     <= 8'h00;
            down_count    <= 8'h00;
            presc_count   <= 8'h00;
            expired_reg   <= 1'b0;
            reset_req_reg <= 1'b0;
        end else begin
            // Reset request is a single-cycle pulse
            reset_req_reg <= 1'b0;

            // ---- Watchdog Counting & Kick Handling ----
            // PRIORITY RULE: A valid kick takes priority over timeout if they
            // occur in the exact same clock cycle.
            if (valid_kick) begin
                down_count  <= reload_reg;
                presc_count <= presc_reg;
            end else if (ctrl_reg[0]) begin
                // Watchdog is active: prescaler countdown
                if (presc_count == 8'h00) begin
                    presc_count <= presc_reg;
                    // Prescaler tick occurred: decrement down-counter
                    if (down_count == 8'h00) begin
                        // Timeout reached!
                        expired_reg <= 1'b1;
                        if (ctrl_reg[1]) begin
                            reset_req_reg <= 1'b1;
                        end
                        // Reload counter for subsequent timeout monitoring
                        down_count <= reload_reg;
                    end else begin
                        down_count <= down_count - 8'h01;
                    end
                end else begin
                    presc_count <= presc_count - 8'h01;
                end
            end

            // ---- IO Register Writes ----
            // Register writes take precedence over counting updates
            if (io_wr) begin
                case (io_port)
                    8'h50: begin
                        ctrl_reg <= io_wdata[1:0];
                        // If transitioning from disabled to enabled, load counter immediately
                        if (!ctrl_reg[0] && io_wdata[0]) begin
                            down_count  <= reload_reg;
                            presc_count <= presc_reg;
                        end
                    end
                    8'h51: begin
                        reload_reg <= io_wdata;
                        // If watchdog is not active, also preset down_count
                        if (!ctrl_reg[0]) begin
                            down_count <= io_wdata;
                        end
                    end
                    8'h52: begin
                        presc_reg <= io_wdata;
                        // If watchdog is not active, also preset presc_count
                        if (!ctrl_reg[0]) begin
                            presc_count <= io_wdata;
                        end
                    end
                    8'h54: begin
                        // Software write to WD_STATUS clears the sticky expired flag
                        expired_reg <= 1'b0;
                    end
                    default: ;
                endcase
            end
        end
    end

endmodule

`endif
