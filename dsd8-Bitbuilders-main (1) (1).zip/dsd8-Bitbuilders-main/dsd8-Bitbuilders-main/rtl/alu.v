// alu.v -- arithmetic, logic, shifts, and the four flag outputs
// Owner: member B -- this is YOUR module; you are individually examined
// on it at the oral defence, and it is the one Section 8.5 (R24-R25)
// requires a constrained-random self-checking testbench for.
// Spec: Section 5.7 and Section 2.3. Purely combinational. Port list
// is FROZEN. `op` is the instruction opcode directly (R15) -- no
// separate ALU-control encoding needed.
//
// This file intentionally does NOT implement the truth table for you
// -- Section 2.3 already gives you the exact carry, overflow and flag
// definitions; writing the RTL from that table (and then proving it
// correct with your own random test) is the actual exercise. See
// tools/dsd8sim.py if you want a second, independent statement of the
// same semantics in Python to cross-check your own reading of the spec
// against -- but write this module yourself.

`ifndef ALU_V
`define ALU_V

module alu (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire [3:0] op,     // instruction opcode: 0x4 ADD .. 0xB CMP
    output wire [7:0] result,
    output wire       flag_z,
    output wire       flag_n,
    output wire       flag_c,
    output wire       flag_v
);

    wire [8:0] add9;
    wire [8:0] sub9;
    wire [7:0] result_add;
    wire [7:0] result_sub;
    wire [7:0] result_logic;
    wire       n_and;
    wire       n_or;
    wire       n_xor;
    wire [7:0] result_shift_left;
    wire [7:0] result_shift_right;
    wire       z_add;
    wire       z_sub;
    wire       n_add;
    wire       n_sub;
    wire       c_add;
    wire       c_sub;
    wire       v_add;
    wire       v_sub;

    assign add9 = {1'b0, a} + {1'b0, b};
    assign sub9 = {1'b0, a} + {1'b0, ~b} + 9'h001;

    assign result_add = add9[7:0];
    assign result_sub = sub9[7:0];
    assign result_logic = (op == 4'h6) ? (a & b) :
                          (op == 4'h7) ? (a | b) :
                          (a ^ b);
    assign result_shift_left = {a[6:0], 1'b0};
    assign result_shift_right = {1'b0, a[7:1]};
    assign n_and = a[7] & b[7];
    assign n_or = a[7] | b[7];
    assign n_xor = a[7] ^ b[7];

    assign z_add = (result_add == 8'h00);
    assign z_sub = (result_sub == 8'h00);
    assign n_add = result_add[7];
    assign n_sub = result_sub[7];
    assign c_add = add9[8];
    assign c_sub = sub9[8];
    assign v_add = ((a[7] == b[7]) && (result_add[7] != a[7]));
    assign v_sub = ((a[7] != b[7]) && (result_sub[7] != a[7]));

    assign result = (op == 4'h4) ? result_add :
                   (op == 4'h5) ? result_sub :
                   (op == 4'h6) ? (a & b) :
                   (op == 4'h7) ? (a | b) :
                   (op == 4'h8) ? (a ^ b) :
                   (op == 4'h9) ? result_shift_left :
                   (op == 4'hA) ? result_shift_right :
                   (op == 4'hB) ? result_sub :
                   8'h00;

    assign flag_z = (op == 4'h4) ? z_add :
                    (op == 4'h5) ? z_sub :
                    (op == 4'h6) ? ((a & b) == 8'h00) :
                    (op == 4'h7) ? ((a | b) == 8'h00) :
                    (op == 4'h8) ? ((a ^ b) == 8'h00) :
                    (op == 4'h9) ? (result_shift_left == 8'h00) :
                    (op == 4'hA) ? (result_shift_right == 8'h00) :
                    (op == 4'hB) ? z_sub :
                    1'b0;

    assign flag_n = (op == 4'h4) ? n_add :
                    (op == 4'h5) ? n_sub :
                    (op == 4'h6) ? n_and :
                    (op == 4'h7) ? n_or :
                    (op == 4'h8) ? n_xor :
                    (op == 4'h9) ? result_shift_left[7] :
                    (op == 4'hA) ? result_shift_right[7] :
                    (op == 4'hB) ? n_sub :
                    1'b0;

    assign flag_c = (op == 4'h4) ? c_add :
                    (op == 4'h5) ? c_sub :
                    (op == 4'h6) ? 1'b0 :
                    (op == 4'h7) ? 1'b0 :
                    (op == 4'h8) ? 1'b0 :
                    (op == 4'h9) ? a[7] :
                    (op == 4'hA) ? a[0] :
                    (op == 4'hB) ? c_sub :
                    1'b0;

    assign flag_v = (op == 4'h4) ? v_add :
                    (op == 4'h5) ? v_sub :
                    (op == 4'h6) ? 1'b0 :
                    (op == 4'h7) ? 1'b0 :
                    (op == 4'h8) ? 1'b0 :
                    (op == 4'h9) ? 1'b0 :
                    (op == 4'hA) ? 1'b0 :
                    (op == 4'hB) ? v_sub :
                    1'b0;

endmodule

`endif
