// dsd8_top.v -- system top level
// Owner: shared (whole team integrates this together)
// Spec: Section 5.1. Port list is FROZEN -- do not rename or resize.
//
// Integrated with Watchdog Timer:
//   - Watchdog expired output drives LED[7] as an immediate visual alarm
//   - Watchdog reset request pulse resets the CPU if reset-on-expiry is enabled

`ifndef DSD8_TOP_V
`define DSD8_TOP_V

module dsd8_top (
    input  wire       clk,
    input  wire       rst_n,       // synchronous, active low
    input  wire [7:0] switches,    // board slide switches  -> port 0x00
    input  wire [4:0] buttons,     // {btnU,btnD,btnL,btnR,btnC} -> port 0x01
    output wire [7:0] leds,        // board LEDs             <- port 0x02 + watchdog alarm
    output wire [6:0] seg,         // seven-segment segments <- port 0x10
    output wire [3:0] an,          // seven-segment digit enables
    output wire       halted       // asserted after HLT retires
);

    wire [8:0]  imem_addr;
    wire [15:0] imem_data;
    wire [7:0]  io_port, io_wdata, io_rdata;
    wire        io_rd, io_wr, io_ready;
    wire [7:0]  seg_value, seg_enable;
    wire [7:0]  bus_leds;
    wire        wd_expired;
    wire        wd_reset_req;

    // CPU reset logic:
    // When the watchdog timer asserts reset_req (active high pulse),
    // cpu_rst_n is driven low to synchronously reset the CPU.
    wire cpu_rst_n = rst_n & (~wd_reset_req);

    dsd8_cpu cpu (
        .clk             (clk),
        .rst_n           (cpu_rst_n),
        .imem_addr       (imem_addr),
        .imem_data       (imem_data),
        .io_port         (io_port),
        .io_wdata        (io_wdata),
        .io_rdata        (io_rdata),
        .io_rd           (io_rd),
        .io_wr           (io_wr),
        .io_ready        (io_ready),
        .halted          (halted),
        .retire          (),
        .retire_pc       (),
        .retire_ir       (),
        .retire_rf_we    (),
        .retire_rf_addr  (),
        .retire_rf_data  (),
        .retire_mem_we   (),
        .retire_mem_addr (),
        .retire_mem_data (),
        .retire_flags    ()
    );

    instr_memory imem (
        .clk  (clk),
        .addr (imem_addr),
        .data (imem_data)
    );

    io_bus bus (
        .clk           (clk),
        .rst_n         (rst_n),
        .io_port       (io_port),
        .io_wdata      (io_wdata),
        .io_rdata      (io_rdata),
        .io_rd         (io_rd),
        .io_wr         (io_wr),
        .io_ready      (io_ready),
        .switches      (switches),
        .buttons       (buttons),
        .leds          (bus_leds),
        .seg_value     (seg_value),
        .seg_enable    (seg_enable),
        .periph_port   (),
        .periph_wdata  (),
        .periph_rdata  (8'h00),
        .periph_rd     (),
        .periph_wr     (),
        .periph_ready  (1'b1),
        .wd_expired    (wd_expired),
        .wd_reset_req  (wd_reset_req)
    );

    assign seg = seg_value[6:0];
    assign an  = seg_enable[3:0];

    // Connect watchdog expired indicator to LED[7]:
    // When expired, LED[7] turns ON. LEDs 6:0 remain standard software outputs.
    assign leds = {bus_leds[7] | wd_expired, bus_leds[6:0]};

endmodule

`endif
