// io_bus.v -- port address decode and the io_ready handshake
// Owner: member C -- this is YOUR module; you are individually examined
// on it at the oral defence.
// Spec: Section 7. The CPU-facing side of this module (the six signals
// wired to dsd8_cpu) is frozen by Section 7.1's signal table.
//
// Address Decoding:
//   0x00: Switches (read)
//   0x01: Buttons  (read)
//   0x02: LEDs     (write)
//   0x10: 7-segment segment values (write)
//   0x11: 7-segment digit enable (write)
//   0x20..0x40: Forwarded to sim/peripherals.v (UART, timer, SLOW_ECHO)
//   0x50..0x55: Watchdog Timer registers (WD_CTRL, WD_RELOAD, WD_PRESC, WD_KICK, WD_STATUS, WD_COUNT)

`ifndef IO_BUS_V
`define IO_BUS_V

`ifndef WATCHDOG_TIMER_V
`include "watchdog_timer.v"
`endif

module io_bus (
    input  wire        clk,
    input  wire        rst_n,

    // ---- CPU-facing side: matches dsd8_cpu's io_* ports exactly ----
    input  wire [7:0]  io_port,
    input  wire [7:0]  io_wdata,
    output wire [7:0]  io_rdata,
    input  wire        io_rd,
    input  wire        io_wr,
    output wire        io_ready,

    // ---- board-facing side (Section 7.2 standard port map) ----
    input  wire [7:0]  switches,     // port 0x00
    input  wire [4:0]  buttons,      // port 0x01
    output reg  [7:0]  leds,         // port 0x02
    output reg  [7:0]  seg_value,    // port 0x10
    output reg  [7:0]  seg_enable,   // port 0x11

    // ---- forwarded to sim/peripherals.v for UART / timer / SLOW_ECHO ----
    output wire [7:0]  periph_port,
    output wire [7:0]  periph_wdata,
    input  wire [7:0]  periph_rdata,
    output wire        periph_rd,
    output wire        periph_wr,
    input  wire        periph_ready,

    // ---- Watchdog Timer hardware status / control outputs ----
    output wire        wd_expired,
    output wire        wd_reset_req
);

    // Watchdog Timer instance & decode (ports 0x50 .. 0x55)
    wire [7:0] wd_rdata;
    wire       wd_ready;
    wire       is_wd = (io_port >= 8'h50 && io_port <= 8'h55);

    watchdog_timer wdt (
        .clk       (clk),
        .rst_n     (rst_n),
        .io_port   (io_port),
        .io_wdata  (io_wdata),
        .io_rdata  (wd_rdata),
        .io_rd     (io_rd),
        .io_wr     (io_wr),
        .io_ready  (wd_ready),
        .expired   (wd_expired),
        .reset_req (wd_reset_req)
    );

    // Read mux: decode switches, buttons, watchdog registers, or reference peripherals
    assign io_rdata     = (io_port == 8'h00) ? switches :
                          (io_port == 8'h01) ? {3'b000, buttons} :
                          (is_wd)            ? wd_rdata :
                          (io_port < 8'h40)  ? 8'h00 : periph_rdata;

    // Handshake: Watchdog and internal board registers ready in 1 cycle
    assign io_ready     = (is_wd)            ? wd_ready :
                          (io_port < 8'h40)  ? 1'b1 : periph_ready;

    assign periph_port  = io_port;
    assign periph_wdata = io_wdata;
    assign periph_rd    = io_rd && (io_port >= 8'h20 && io_port <= 8'h40);
    assign periph_wr    = io_wr && (io_port >= 8'h20 && io_port <= 8'h40);

    always @(posedge clk) begin
        if (!rst_n) begin
            leds       <= 8'h00;
            seg_value  <= 8'h00;
            seg_enable <= 8'h00;
        end else begin
            if (io_wr && io_ready && io_port == 8'h02) leds <= io_wdata;
            if (io_wr && io_ready && io_port == 8'h10) seg_value <= io_wdata;
            if (io_wr && io_ready && io_port == 8'h11) seg_enable <= io_wdata;
        end
    end

    // verilator lint_off UNUSEDSIGNAL
    wire [7:0] unused_switches   = switches;
    wire [4:0] unused_buttons    = buttons;
    wire [7:0] unused_periph_rd  = periph_rdata;
    wire       unused_periph_rdy = periph_ready;
    // verilator lint_on UNUSEDSIGNAL

endmodule

`endif
