; sample04_watchdog_normal.asm
; Normal Watchdog Operation Demonstration
; CPU enables the Watchdog Timer, configures reload and prescaler,
; and services (kicks) the watchdog inside a periodic execution loop.
; Because kicks arrive well before timeout, the expired flag is NEVER set,
; and the watchdog alarm LED remains OFF (LED 7 = 0).
;
; Register assignments:
;   R0: Constant 0 / scratch
;   R1: Loop counter
;   R2: Step decrement (1)
;   R3: Kick key (0xA5)
;   R4: Configuration values (RELOAD, PRESC, CTRL)
;   R7: Watchdog status readback (must remain 0x02 = enabled, expired=0)

        ; 1. Configure Watchdog Timer registers
        LDI  R4, 15        ; RELOAD = 15
        OUT  0x51, R4      ; Write WD_RELOAD (0x51)

        LDI  R4, 3         ; PRESCALE = 3 (timeout = (15+1)*(3+1) = 64 cycles)
        OUT  0x52, R4      ; Write WD_PRESC (0x52)

        LDI  R4, 1         ; Bit 0 = Enable, Bit 1 = 0 (no reset)
        OUT  0x50, R4      ; Write WD_CTRL (0x50) - starts watchdog

        ; 2. Initialize kick parameters & loop
        LDI  R3, 0xA5      ; R3 = Valid kick key 0xA5
        LDI  R2, 1         ; R2 = 1
        LDI  R1, 5         ; Perform 5 loop iterations

LOOP:   ; Service / kick the watchdog periodically
        OUT  0x53, R3      ; Write 0xA5 to WD_KICK (0x53) - reloads counter!

        ; Do some work (decrement loop counter)
        SUB  R1, R1, R2
        BNE  LOOP          ; Repeat loop until R1 reaches 0

        ; 3. Verify Watchdog status
        IN   R7, 0x54      ; Read WD_STATUS (0x54): bit 1 is enabled (1), bit 0 is expired (0)
                           ; Expected R7 = 0x02
        LDI  R0, 0x55      ; Normal status indicator to LEDs (LED 7 is 0)
        OUT  0x02, R0      ; Output to LEDs: LED7 remains OFF!
        HLT
