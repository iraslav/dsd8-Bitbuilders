; sample05_watchdog_hang.asm
; Watchdog Timeout / CPU Hang Demonstration
; Configures the watchdog with a short timeout, kicks it once,
; then enters an execution loop WITHOUT kicking.
; The watchdog reaches timeout, asserts the sticky EXPIRED flag,
; and illuminates the watchdog alarm LED (LED 7 = 1).
;
; Register assignments:
;   R1: Loop counter
;   R2: Step decrement (1)
;   R3: Kick key (0xA5)
;   R4: Configuration values
;   R7: Watchdog status readback (must become 0x03 = enabled, expired)

        ; 1. Configure short timeout: RELOAD = 2, PRESCALE = 1
        ; Timeout = (2 + 1) * (1 + 1) = 6 cycles
        LDI  R4, 2         ; RELOAD = 2
        OUT  0x51, R4

        LDI  R4, 1         ; PRESCALE = 1
        OUT  0x52, R4

        LDI  R4, 1         ; Enable Watchdog (CTRL = 1)
        OUT  0x50, R4

        ; 2. Initial kick to show servicing works
        LDI  R3, 0xA5
        OUT  0x53, R3      ; Kick

        ; 3. Simulate program deadlock / hang:
        ; Loop without sending any kicks!
        LDI  R1, 20        ; Wait for timeout
        LDI  R2, 1
HANG:   SUB  R1, R1, R2
        BNE  HANG          ; Loop 20 times (exceeding 6-cycle timeout)

        ; 4. Check expired status
        IN   R7, 0x54      ; Read WD_STATUS: bit 0 (expired) is 1!
                           ; Expected R7 = 0x03 (enabled=1, expired=1)
        HLT
