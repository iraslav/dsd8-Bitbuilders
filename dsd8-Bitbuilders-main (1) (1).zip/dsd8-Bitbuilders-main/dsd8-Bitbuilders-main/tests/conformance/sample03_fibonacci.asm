; sample03_fibonacci.asm
; Computes the first 8 Fibonacci numbers, stores them in Data Memory (0x10..0x17),
; loads back from memory, and outputs F(8) = 21 (0x15) to the LEDs.
;
; Expected results:
;   R1 = 21 (0x15)
;   R2 = 34 (0x22)
;   R7 = 1  (loaded from mem[0x10])
;   LEDs = 0x15

        LDI  R1, 0      ; F(0)
        LDI  R2, 1      ; F(1)
        LDI  R3, 8      ; loop count (8 steps)
        LDI  R4, 1      ; constant 1
        LDI  R6, 0x10   ; memory base address

LOOP:   ST   [R6], R2   ; store current Fibonacci number into memory
        ADD  R6, R6, R4 ; increment memory address
        ADD  R5, R1, R2 ; R5 = next Fibonacci number
        MOV  R1, R2     ; R1 = previous Fibonacci
        MOV  R2, R5     ; R2 = current Fibonacci
        SUB  R3, R3, R4 ; decrement loop counter
        BNE  LOOP       ; loop until counter reaches 0

DONE:   OUT  0x02, R1   ; output F(8) = 21 (0x15) to LEDs
        LDI  R7, 0x10   ; test memory read
        LD   R7, [R7]   ; R7 = mem[0x10] (should be 1)
        HLT
