# University Presentation Visuals: Watchdog Timer Subsystem
**Course: Digital System Design (DSD)**  
**Target Audience: Professor, Course Examiners, and Engineering Peers**

---

## Slide 1: The Problem — Why Embedded CPUs Fail

```
+------------------------------------------------------------------------------+
|                              THE REAL-WORLD PROBLEM                          |
+------------------------------------------------------------------------------+
|                                                                              |
|  [ Microprocessor Firmware ]                                                 |
|          |                                                                   |
|          +---> Infinite Loop waiting for faulty external sensor              |
|          +---> Pointer corruption / Stack overflow into unmapped space       |
|          +---> Cosmic ray / EMI bit flip in Program Counter                  |
|          |                                                                   |
|          v                                                                   |
|   +---------------+                                                          |
|   |   CPU HANGS   |  <--- System freezes indefinitely!                       |
|   +---------------+                                                          |
|          |                                                                   |
|          +---> Industrial plant stops operating                              |
|          +---> Medical device loses monitoring                               |
|          +---> Requires human manual power-cycle                             |
|                                                                              |
+------------------------------------------------------------------------------+
```

### Key Speaking Points
1. Even mathematically proven software crashes when subjected to real-world timing jitter, bus stalls, or electromagnetic interference (EMI).
2. Once a CPU enters a deadlock, it cannot execute self-recovery code because its execution thread is trapped.
3. Recovery requires an **autonomous, external hardware component** operating independently of CPU software.

---

## Slide 2: The Solution — Hardware Watchdog Timer

```
+------------------------------------------------------------------------------+
|                              THE HARDWARE SOLUTION                           |
+------------------------------------------------------------------------------+
|                                                                              |
|             +-----------------------+                                        |
|             |      DSD-8 CPU        |                                        |
|             +-----------+-----------+                                        |
|                         |                                                    |
|           1. Normal:    |   3. Failure Recovery:                             |
|           Sends Kick    |   Synchronous Reset Pulse                          |
|             (0xA5)      |       (cpu_rst_n)                                  |
|                         v            ^                                       |
|             +-----------+------------+-------+                               |
|             |        Watchdog Timer          |                               |
|             |   Independent Hardware Counter |                               |
|             +----------------+---------------+                               |
|                              |                                               |
|                              v 2. Timeout Alarm                              |
|                      +-------+-------+                                       |
|                      |  LED 7 Alarm  |                                       |
|                      +---------------+                                       |
|                                                                              |
+------------------------------------------------------------------------------+
```

### Key Speaking Points
1. The Watchdog Timer is an electronic supervisor mapped onto the memory-mapped IO bus.
2. Under healthy execution, software periodically issues a "kick" (`0xA5`).
3. If firmware locks up and fails to kick, the hardware detects the absence of activity, triggers an immediate visual alarm on LED 7, and reboots the processor.

---

## Slide 3: How the Hardware Works (Internal Microarchitecture)

```
                       +-------------------+
                       | System Clock (clk)|
                       +---------+---------+
                                 |
                                 v
                     +-----------+-----------+
                     |  Prescaler Down-Count | <--- WD_PRESC (0x52)
                     |   (Divides by N + 1)  |
                     +-----------+-----------+
                                 |
                                 | presc_tick (1 pulse every N+1 clocks)
                                 v
                     +-----------+-----------+
    WD_KICK (0x53)   |    Main Down-Counter  | <--- WD_RELOAD (0x51)
   (Key 0xA5 reloads |  (Decrements on tick) |
       counter) ---> +-----------+-----------+
                                 |
                                 | Reaches 0 (Timeout)
                                 v
                     +-----------+-----------+
                     |   Sticky Expired Reg  | <--- WD_STATUS (0x54)
                     |    (Remains 1 until   |
                     |   cleared by software)|
                     +-----+-----------+-----+
                           |           |
                           v           v
                     +-----+----+ +----+------+
                     |  LED 7   | | CPU Reset |
                     | Indicator| |   Pulse   |
                     +----------+ +-----------+
```

### Architectural Highlights
- **Prescaler Unit:** Converts nanosecond system clocks into usable millisecond timeouts.
- **Key-Protected Kick:** Requires writing specific byte `0xA5`. Stray pointers writing random data cannot trick the watchdog.
- **Dual Reaction:** Immediate visual LED alarm + optional 1-cycle CPU reset pulse.

---

## Slide 4: Timeout Formula & Practical Example

$$\mathbf{Timeout\ Cycles = (WD\_RELOAD + 1) \times (WD\_PRESC + 1)}$$

```
+------------------------------------------------------------------------------+
|                          100 MHz CLOCK DEMONSTRATION                         |
+------------------------------------------------------------------------------+
|                                                                              |
|   Clock Period: 10 ns (100 MHz)                                              |
|                                                                              |
|   Configuration:                                                             |
|   - WD_RELOAD = 99                                                           |
|   - WD_PRESC  = 9,999                                                        |
|                                                                              |
|   Calculation:                                                               |
|   Timeout Cycles = (99 + 1) * (9,999 + 1) = 100 * 10,000 = 1,000,000 cycles |
|                                                                              |
|   Real-world Timeout:                                                        |
|   Timeout = 1,000,000 * 10 ns = 10 milliseconds                              |
|                                                                              |
|   Safety Margin: Software kicks every 2 ms -> Safety factor of 5x!           |
|                                                                              |
+------------------------------------------------------------------------------+
```

---

## Slide 5: Scenario Comparison — Normal vs. Hang Execution

| Metric | Normal Operation (`sample04`) | CPU Hang Failure (`sample05`) |
|:---|:---|:---|
| **Software Behavior** | Executes computation loop, writes `0xA5` to port `0x53` | Enters infinite loop without servicing port `0x53` |
| **Counter State** | Continuously reloads back to `WD_RELOAD` | Decrements down: $2 \rightarrow 1 \rightarrow 0$ |
| **Timeout Reached?** | **NO** (Postponed by kicks) | **YES** (Counts to zero) |
| **Expired Flag (`0x54[0]`)** | Stays `0` | Latches to `1` (Sticky) |
| **LED 7 Output** | **OFF** | **ON** (Bright red alarm) |
| **CPU Reset (`cpu_rst_n`)** | Operates normally | Asserted low if enabled, rebooting CPU to `PC=0` |

---

## Slide 6: Verification & Final Deliverables

```
+------------------------------------------------------------------------------+
|                      100% PASSING TEST VERIFICATION                          |
+------------------------------------------------------------------------------+
|                                                                              |
|   [9/9 Unit Testbenches Passed]                                              |
|   [x] tb_watchdog_timer.v: All 15 functional requirements certified          |
|   [x] tb_dsd8_top_watchdog.v: Complete CPU + IO + WDT + LED + Reset loop     |
|   [x] tb_alu, tb_control, tb_memory, tb_decoder, tb_pc, tb_rf all PASS       |
|                                                                              |
|   [5/5 Conformance Assembly Programs Passed]                                 |
|   [x] sample01_multiply: 100% trace match                                    |
|   [x] sample02_popcount: 100% trace match                                    |
|   [x] sample03_fibonacci: 100% trace match                                   |
|   [x] sample04_watchdog_normal: 100% trace match (Kicked, LED OFF)           |
|   [x] sample05_watchdog_hang: 100% trace match (Expired, LED ON)             |
|                                                                              |
+------------------------------------------------------------------------------+
```
