# Watchdog Timer Integration for the DSD-8 Microprocessor
**Project Documentation for Digital System Design (DSD)**  
*Team Bitbuilders &bull; 8-bit RISC Hardware Subsystem*

---

## 1. Executive Summary & Overview

### What is a Watchdog Timer?
A **Watchdog Timer (WDT)** is a dedicated hardware safety monitor integrated into a microprocessor system. It acts like an electronic "dead man's switch": software running on the CPU must periodically "kick" (reset or service) the timer before it counts down to zero. 

If the software encounters an infinite loop, memory deadlock, hardware glitch, or fatal crash and ceases kicking the watchdog, the timer **expires**. Upon expiry, the hardware:
1. Immediately illuminates a dedicated hardware alarm LED (**LED 7** on the board).
2. Sets a **sticky status flag** in an internal register that persists across software crashes.
3. Optionally triggers a **hardware reset pulse** to reboot the CPU back to its initial reset vector (`PC = 0x000`).

```
                    +------------------------------------+
                    |        DSD-8 CPU Core              |
                    |  (Runs user firmware & software)   |
                    +-----------------+------------------+
                                      |
                      Periodic Kick   |   Hardware Reset
                         (0xA5)       |    (cpu_rst_n)
                                      v          ^
                    +-----------------+----------+-------+
                    |        Watchdog Timer              |
                    |   Counts down on system clock      |
                    +-----------------+------------------+
                                      |
                             Timeout  | (expired = 1)
                                      v
                             +-----------------+
                             |  LED 7 (Alarm)  |
                             +-----------------+
```

---

## 2. Why Do We Need a Watchdog Timer?

In embedded systems, automotive controllers, medical devices, aerospace instruments, and industrial automation, microprocessors must operate autonomously for months or years without human intervention.

Software is susceptible to:
- **Infinite Loops:** e.g., waiting for an external sensor or button that never responds.
- **Deadlocks:** circular wait states in concurrent execution.
- **Single-Event Upsets (SEU):** electrical noise, EMI, or alpha particles flipping a register bit and sending the Program Counter into unmapped memory.
- **Stack / Memory Corruption:** overwriting return addresses or data pointers.

Without a Watchdog Timer, a microprocessor that hangs remains frozen indefinitely, requiring a human to manually power-cycle the board. With our synthesizable Watchdog Timer integrated directly onto the DSD-8 internal IO bus, the system self-detects deadlocks and automatically recovers within milliseconds.

---

## 3. Core Operating Principles

### A. What are RELOAD and PRESCALE?
- **Prescaler (`WD_PRESC` at 0x52):**  
  Microprocessor clocks run at very high frequencies (e.g., 100 MHz = 10 ns per clock cycle). If an 8-bit counter decremented directly on every clock edge, it would overflow in just 256 clock cycles (2.56 microseconds)—far too fast for normal software routines.  
  The prescaler acts as a clock divider: it counts down from its loaded value to 0, producing a single-cycle **prescaler tick** every $(PRESCALE + 1)$ clock cycles.

- **Reload Register (`WD_RELOAD` at 0x51):**  
  Holds the initial duration for the main down-counter. Whenever the watchdog is enabled or receives a valid kick, the down-counter is loaded with this value. The down-counter only decrements upon receiving a prescaler tick.

### B. What is a "Kick"?
A **kick** (also known as "petting" or "servicing" the watchdog) is an intentional write by firmware to confirm normal execution.
- In our design, software writes the unique security key `0xA5` to port `0x53` (`WD_KICK`).
- Writing `0xA5` resets both the prescaler and down-counter back to their full reload values.
- Writing any other value (e.g., `0x00`, `0x55`, `0xFF`) is strictly ignored to prevent runaway code from accidentally resetting the watchdog.
- **Priority Rule:** If a kick and a timeout expiry occur in the exact same clock cycle, the hardware gives absolute priority to the kick, reloading the counter and averting false expiry.

### C. What is a Sticky Expired Flag?
The **expired flag** (`WD_STATUS[0]` at 0x54) is set to `1` the moment the down-counter reaches zero. It is **sticky**—it remains `1` even if the counter reloads or the CPU restarts, until software explicitly issues a clear command (by writing to `0x54`). This allows bootloader software to inspect the register after reset to determine whether the reboot was caused by a normal power-on or a watchdog hang recovery.

---

## 4. Timeout Mathematical Formula & Calculation

The exact hardware timeout duration in clock cycles is governed by:

$$\text{Timeout Cycles} = (\text{WD\_RELOAD} + 1) \times (\text{WD\_PRESC} + 1)$$

Given system clock frequency $f_{\text{clk}}$ and clock period $T_{\text{clk}} = \frac{1}{f_{\text{clk}}}$:

$$\text{Timeout Time} = \text{Timeout Cycles} \times T_{\text{clk}} = (\text{WD\_RELOAD} + 1) \times (\text{WD\_PRESC} + 1) \times T_{\text{clk}}$$

### Practical University Example (100 MHz System Clock)
- System Clock: $100\text{ MHz} \implies T_{\text{clk}} = 10\text{ ns}$
- $\text{WD\_RELOAD} = 99$
- $\text{WD\_PRESC} = 9999$ (represented via software prescaler or staged counters)
- $\text{Timeout Cycles} = (99 + 1) \times (9999 + 1) = 100 \times 10,000 = 1,000,000\text{ cycles}$
- $\text{Timeout Time} = 1,000,000 \times 10\text{ ns} = 10\text{ ms}$

### Testbench Example (Fast Verification)
- $\text{WD\_RELOAD} = 3$
- $\text{WD\_PRESC} = 1$
- $\text{Timeout Cycles} = (3 + 1) \times (1 + 1) = 4 \times 2 = 8\text{ clock cycles}$

---

## 5. Register Map & Hardware Address Allocation

Section 7.2 of the DSD-8 specification reserves ports `0x00-0x1F` for board peripherals (switches, buttons, LEDs, 7-segment) and ports `0x20-0x40` for reference communication models (UART, timer, SLOW_ECHO).

Ports **`0x50` through `0x55`** are completely unallocated and assigned to the Watchdog Timer with zero address conflicts:

| Address | Register Name | Access | Bit Definitions | Description |
|:-------:|:-------------:|:------:|:----------------|:------------|
| **`0x50`** | `WD_CTRL` | R/W | `[0]`: Enable<br/>`[1]`: Reset-On-Expiry<br/>`[7:2]`: Reserved (0) | Writing `1` enables the countdown. Writing `3` (`2'b11`) enables countdown and asserts CPU reset pulse upon timeout. |
| **`0x51`** | `WD_RELOAD` | R/W | `[7:0]`: Reload Value | 8-bit initial value copied to down counter upon enable or valid kick. |
| **`0x52`** | `WD_PRESC` | R/W | `[7:0]`: Prescaler Value | 8-bit clock divider value. Down counter decrements every `(PRESC+1)` clocks. |
| **`0x53`** | `WD_KICK` | Write | `[7:0]`: Kick Key | Write `0xA5` to service/kick. All other values ignored. |
| **`0x54`** | `WD_STATUS` | R/W | `[0]`: Expired Flag (Sticky)<br/>`[1]`: Enabled Status<br/>`[7:2]`: 0 | Reads `1` if timeout has occurred. Writing any value (e.g., `0x00`) clears the expired flag. |
| **`0x55`** | `WD_COUNT` | Read | `[7:0]`: Current Count | Real-time readback of internal down-counter value. |

All registers feature single-cycle read and write handshaking (`io_ready = 1'b1`), introducing zero wait-states.

---

## 6. Hardware Architecture & Integration Details

### Integration in `rtl/io_bus.v`
The watchdog timer (`rtl/watchdog_timer.v`) is instantiated inside `io_bus.v`. The bus decoder detects when `io_port >= 0x50 && io_port <= 0x55`:
```verilog
wire is_wd = (io_port >= 8'h50 && io_port <= 8'h55);

assign io_rdata = (io_port == 8'h00) ? switches :
                  (io_port == 8'h01) ? {3'b000, buttons} :
                  (is_wd)            ? wd_rdata :
                  (io_port < 8'h40)  ? 8'h00 : periph_rdata;

assign io_ready = (is_wd)            ? wd_ready :
                  (io_port < 8'h40)  ? 1'b1 : periph_ready;
```

### Integration in `rtl/dsd8_top.v`
In `dsd8_top.v`, two critical connections are made:
1. **LED Alarm Indication:**  
   The watchdog's `expired` output is mapped directly to **LED 7**:
   ```verilog
   assign leds = {bus_leds[7] | wd_expired, bus_leds[6:0]};
   ```
   When the watchdog is healthy (`expired == 0`), all 8 LEDs operate normally via software writes to port `0x02`. When a hang occurs (`expired == 1`), LED 7 turns bright red immediately in hardware even if the CPU is completely locked up.

2. **CPU Reset Merging:**  
   The watchdog's 1-cycle reset request pulse `wd_reset_req` is combined with the external active-low system reset `rst_n`:
   ```verilog
   wire cpu_rst_n = rst_n & (~wd_reset_req);
   ```
   This resets the CPU core while preserving the watchdog's internal sticky registers, allowing post-reset fault inspection.

---

## 7. Visual Architecture & Timing Diagrams

High-resolution vector diagrams and Mermaid definitions are located in [`documentation/diagrams/`](diagrams/):

1. **Overall Architecture:**  
   Shows CPU $\leftrightarrow$ IO Bus $\leftrightarrow$ Watchdog $\rightarrow$ LED 7 and CPU reset loop.  
   Vector file: [`diagram1_overall_architecture.svg`](diagrams/diagram1_overall_architecture.svg)  
   Mermaid definition: [`diagram1_overall_architecture.mmd`](diagrams/diagram1_overall_architecture.mmd)

2. **Internal Watchdog Microarchitecture:**  
   Shows clock prescaler, tick generator, down-counter, kick comparator, and expired latch.  
   Vector file: [`diagram2_internal_architecture.svg`](diagrams/diagram2_internal_architecture.svg)  
   Mermaid definition: [`diagram2_internal_architecture.mmd`](diagrams/diagram2_internal_architecture.mmd)

3. **Working Flowchart:**  
   Step-by-step state machine from initialization to kick decision and timeout handling.  
   Vector file: [`diagram3_flowchart.svg`](diagrams/diagram3_flowchart.svg)  
   Mermaid definition: [`diagram3_flowchart.mmd`](diagrams/diagram3_flowchart.mmd)

4. **Timing Diagram:**  
   Cycle-accurate waveforms for clock, prescaler ticks, down-counter values, kick events, expired flag, and LED 7 for $RELOAD=3, PRESCALE=1$.  
   Vector file: [`diagram4_timing_diagram.svg`](diagrams/diagram4_timing_diagram.svg)  
   Mermaid definition: [`diagram4_timing_diagram.mmd`](diagrams/diagram4_timing_diagram.mmd)

5. **CPU Register Interaction:**  
   Detailed map of `IN` and `OUT` assembly instructions interacting with addresses `0x50-0x55`.  
   Vector file: [`diagram5_register_interaction.svg`](diagrams/diagram5_register_interaction.svg)  
   Mermaid definition: [`diagram5_register_interaction.mmd`](diagrams/diagram5_register_interaction.mmd)

---

## 8. Demonstration Programs

Two fully compatible DSD-8 assembly programs have been implemented under `tests/conformance/`:

### Demo 1: Normal Operation with Regular Kicks (`sample04_watchdog_normal.asm`)
```assembly
; Configures watchdog with timeout = (15+1)*(3+1) = 64 cycles
LDI  R4, 15
OUT  0x51, R4      ; WD_RELOAD = 15
LDI  R4, 3
OUT  0x52, R4      ; WD_PRESC = 3
LDI  R4, 1
OUT  0x50, R4      ; WD_CTRL = 1 (Enable)

LDI  R3, 0xA5      ; Kick key
LDI  R2, 1
LDI  R1, 5         ; 5 loop passes

LOOP:
OUT  0x53, R3      ; Service (kick) watchdog regularly!
SUB  R1, R1, R2
BNE  LOOP

IN   R7, 0x54      ; Readback WD_STATUS -> returns 0x02 (enabled=1, expired=0)
LDI  R0, 0x55
OUT  0x02, R0      ; LEDs display 0x55 (LED 7 remains OFF)
HLT
```
**Result:** Watchdog never expires; LED 7 remains OFF.

### Demo 2: CPU Hang Simulation (`sample05_watchdog_hang.asm`)
```assembly
; Configures short timeout = (2+1)*(1+1) = 6 cycles
LDI  R4, 2
OUT  0x51, R4      ; WD_RELOAD = 2
LDI  R4, 1
OUT  0x52, R4      ; WD_PRESC = 1
LDI  R4, 1
OUT  0x50, R4      ; WD_CTRL = 1 (Enable)

LDI  R3, 0xA5
OUT  0x53, R3      ; Initial kick

; Enter deadlocked loop WITHOUT kicking:
LDI  R1, 20
LDI  R2, 1
HANG:
SUB  R1, R1, R2
BNE  HANG          ; Loops 20 times without servicing watchdog!

IN   R7, 0x54      ; Readback WD_STATUS -> returns 0x03 (enabled=1, expired=1)
HLT
```
**Result:** Watchdog counter hits zero; `expired` asserts HIGH; LED 7 turns bright ON.

---

## 9. Verification & Test Results

A dedicated self-checking unit testbench (`tb/tb_watchdog_timer.v`) and an end-to-end top-level testbench (`tb/tb_dsd8_top_watchdog.v`) were authored and executed:

| Test # | Verified Feature | Result | Notes |
|:------:|:-----------------|:------:|:------|
| 1 | Reset condition | **PASS** | Registers cleared, expired = 0, reset_req = 0 |
| 2 | Watchdog enable and disable | **PASS** | WD_CTRL and WD_STATUS bit 1 toggle correctly |
| 3 | Correct reload value | **PASS** | WD_RELOAD updates and presets counter when disabled |
| 4 | Prescaler functionality | **PASS** | Clock divider operates accurately |
| 5 | Exact timeout cycle count | **PASS** | Verified exact $(RELOAD+1) \times (PRESC+1) = 8$ cycles |
| 6 | Correct kick operation | **PASS** | Key `0xA5` reloads counter and resets prescaler |
| 7 | Invalid kick keys | **PASS** | Keys `0x00`, `0x55`, `0xFF` ignored |
| 8 | Kick postpones expiry | **PASS** | Periodic servicing prevents timeout |
| 9 | Sticky expired flag | **PASS** | Persists across subsequent clock cycles |
| 10 | Clearing expired flag | **PASS** | Software write to `0x54` clears expired bit |
| 11 | Disabled watchdog | **PASS** | Counter remains frozen while disabled |
| 12 | Reset request pulse | **PASS** | Exactly 1 clock cycle pulse when enabled |
| 13 | Counter readback | **PASS** | `WD_COUNT` reflects active down-counter values |
| 14 | Simultaneous kick & expiry | **PASS** | Kick takes priority over timeout |
| 15 | Randomized verification | **PASS** | 20 randomized combinations of reload and prescaler |
| **Top** | **End-to-End System Test** | **PASS** | Tested in full `dsd8_top` with CPU, LED 7, and reset |

### Regression Test Suite Results (`python run_tests.py`)
```
=======================================================
 Running DSD-8 Unit Tests...
=======================================================

TESTBENCH                      RESULT
--------------------------------------------------
tb_alu_example.v               PASS
tb_control_unit.v              PASS
tb_data_memory.v               PASS
tb_dsd8_top_watchdog.v         PASS
tb_flags_reg.v                 PASS
tb_instr_decoder.v             PASS
tb_prog_counter.v              PASS
tb_register_file.v             PASS
tb_watchdog_timer.v            PASS
--------------------------------------------------
9 / 9 passed

=======================================================
 Running DSD-8 Conformance Tests...
=======================================================

TEST                           RESULT
--------------------------------------------------
sample01_multiply              PASS
sample02_popcount              PASS
sample03_fibonacci             PASS
sample04_watchdog_normal       PASS
sample05_watchdog_hang         PASS
--------------------------------------------------
5 / 5 passed

[SUCCESS] All unit tests and conformance tests passed!
```

---

## 10. How to Run & Verify the Project

From the project root:

1. **Execute All Tests (Unit + Conformance):**
   ```bash
   python run_tests.py
   ```
   *(or `.\run_tests.ps1` in PowerShell)*

2. **Run Unit Tests Only:**
   ```bash
   python scripts/run_unit_tests.py
   ```

3. **Run Conformance Tests Only:**
   ```bash
   python scripts/run_conformance.py
   ```

4. **Generate & View Waveform Traces:**
   ```bash
   python scripts/view_waveform.py sample05_watchdog_hang
   ```
   Inspect the resulting `cpu_waveform.vcd` with GTKWave, WaveTrace, or Surfer.

---

## 11. Limitations & Future Improvements

1. **Windowed Watchdog Mode (WWDG):**  
   Currently, software can kick the watchdog at any time before timeout. A windowed watchdog requires kicks to arrive neither too late *nor too early* (detecting fast runaway loops).
2. **Interrupt Before Reset:**  
   An early warning interrupt (Non-Maskable Interrupt, NMI) could be generated when the counter reaches a threshold (e.g., 25% remaining) to log diagnostic data to RAM before CPU reset.
3. **Lock / Password-Protected Enable:**  
   In safety-critical hardware (e.g. automotive ISO 26262), once the watchdog is enabled, software cannot disable it without a hardware reset.
