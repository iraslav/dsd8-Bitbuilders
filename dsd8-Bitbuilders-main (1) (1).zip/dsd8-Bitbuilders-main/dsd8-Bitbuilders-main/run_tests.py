#!/usr/bin/env python3
import os
import subprocess
import sys
from pathlib import Path

# Auto-detect project directory
current_dir = Path(__file__).resolve().parent
if (current_dir / "dsd8-Bitbuilders-main").exists():
    project_dir = current_dir / "dsd8-Bitbuilders-main"
else:
    project_dir = current_dir

scripts_dir = project_dir / "scripts"

print("=" * 55)
print(" Running DSD-8 Unit Tests...")
print("=" * 55)
r1 = subprocess.run([sys.executable, str(scripts_dir / "run_unit_tests.py")], cwd=str(project_dir))

print("\n" + "=" * 55)
print(" Running DSD-8 Conformance Tests...")
print("=" * 55)
r2 = subprocess.run([sys.executable, str(scripts_dir / "run_conformance.py")], cwd=str(project_dir))

if r1.returncode == 0 and r2.returncode == 0:
    print("\n[SUCCESS] All unit tests and conformance tests passed!\n")
    sys.exit(0)
else:
    print("\n[FAILED] Some tests failed.\n")
    sys.exit(1)
