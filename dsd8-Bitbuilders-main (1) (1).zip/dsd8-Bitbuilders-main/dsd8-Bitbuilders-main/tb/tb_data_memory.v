// tb_data_memory.v -- self-checking unit testbench for data_memory
`timescale 1ns/1ps

module tb_data_memory;

    reg        clk;
    reg  [7:0] addr;
    reg        we;
    reg  [7:0] wdata;
    wire [7:0] rdata;

    integer errors;
    integer i;

    data_memory dut (
        .clk(clk),
        .addr(addr),
        .we(we),
        .wdata(wdata),
        .rdata(rdata)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    initial begin
        $display("TESTBENCH: Starting data memory test");
        errors = 0;
        we = 1'b0;
        addr = 8'h00;
        wdata = 8'h00;

        // R16 requirement: reads of never-written locations must return 0x00
        #1;
        for (i = 0; i < 256; i = i + 1) begin
            addr = i;
            #1;
            if (rdata !== 8'h00) begin
                $display("ERROR: Data memory at address %0d expected 0x00, got %h", i, rdata);
                errors = errors + 1;
            end
        end

        // Write to selected locations on negedge clk
        for (i = 0; i < 16; i = i + 1) begin
            @(negedge clk);
            we = 1'b1;
            addr = 8'h20 + i;
            wdata = 8'hA0 + i;
        end
        @(negedge clk);
        we = 1'b0;

        // Verify written data
        for (i = 0; i < 16; i = i + 1) begin
            addr = 8'h20 + i;
            #1;
            if (rdata !== (8'hA0 + i)) begin
                $display("ERROR: Address %h expected %h, got %h", addr, 8'hA0 + i, rdata);
                errors = errors + 1;
            end
        end

        if (errors == 0) begin
            $display("TESTBENCH: PASS");
        end else begin
            $display("TESTBENCH: FAIL (%0d errors)", errors);
        end
        $finish;
    end

endmodule
