// tb_timer.v -- self-checking unit testbench for hardware timer peripheral
`timescale 1ns/1ps

module tb_timer;

    reg        clk;
    reg        rst_n;
    reg  [7:0] port;
    reg  [7:0] wdata;
    wire [7:0] rdata;
    reg        rd;
    reg        wr;
    wire       ready;
    wire [7:0] count;
    wire       enabled;
    wire       overflow;

    integer errors;

    timer dut (
        .clk(clk),
        .rst_n(rst_n),
        .port(port),
        .wdata(wdata),
        .rdata(rdata),
        .rd(rd),
        .wr(wr),
        .ready(ready),
        .count(count),
        .enabled(enabled),
        .overflow(overflow)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    initial begin
        errors = 0;
        port = 8'h00;
        wdata = 8'h00;
        rd = 1'b0;
        wr = 1'b0;

        // Reset check
        rst_n = 1'b0;
        @(negedge clk);
        @(negedge clk);
        rst_n = 1'b1;
        @(negedge clk);
        if (count !== 8'h00 || enabled !== 1'b0) begin
            $display("ERROR: Timer reset state expected count=00, en=0; got count=%h, en=%b", count, enabled);
            errors = errors + 1;
        end

        // 1. Enable timer (write 0x01 to port 0x31)
        port  = 8'h31;
        wdata = 8'h01;
        wr    = 1'b1;
        @(negedge clk);
        wr    = 1'b0;

        // 2. Allow timer to count for 5 cycles
        repeat (5) @(negedge clk);
        if (count !== 8'h05) begin
            $display("ERROR: After 5 enabled cycles, expected count=05, got %h", count);
            errors = errors + 1;
        end

        // 3. Test bus read of port 0x30
        port = 8'h30;
        rd   = 1'b1;
        #1;
        if (rdata !== 8'h05) begin
            $display("ERROR: Bus read port 0x30 expected 05, got %h", rdata);
            errors = errors + 1;
        end
        rd   = 1'b0;

        // 4. Pause timer (write 0x00 to port 0x31)
        port  = 8'h31;
        wdata = 8'h00;
        wr    = 1'b1;
        @(negedge clk);
        wr    = 1'b0;

        repeat (3) @(negedge clk);
        if (count !== 8'h05) begin
            $display("ERROR: Timer should hold count when paused; expected 05, got %h", count);
            errors = errors + 1;
        end

        // 5. Clear timer (write 0x02 to port 0x31: bit 1 = clear)
        port  = 8'h31;
        wdata = 8'h02;
        wr    = 1'b1;
        @(negedge clk);
        wr    = 1'b0;
        @(negedge clk);
        if (count !== 8'h00) begin
            $display("ERROR: Timer clear expected count=00, got %h", count);
            errors = errors + 1;
        end

        if (errors == 0) begin
            $display("TESTBENCH: PASS");
        end else begin
            $display("TESTBENCH: FAIL (%0d errors)", errors);
        end
        $finish;
    end

endmodule
