// tb_control_unit.v -- self-checking unit testbench for control_unit
`timescale 1ns/1ps

module tb_control_unit;

    reg        clk;
    reg        rst_n;
    reg  [3:0] opcode;
    reg  [2:0] cond;
    reg  [3:0] flags;
    reg        io_ready;
    wire       pc_en;
    wire       pc_load;
    wire       rf_we;
    wire       mem_we;
    wire       io_rd;
    wire       io_wr;
    wire       flags_we;
    wire [1:0] wb_sel;
    wire       halted;
    wire       retire;

    integer errors;

    control_unit dut (
        .clk(clk),
        .rst_n(rst_n),
        .opcode(opcode),
        .cond(cond),
        .flags(flags),
        .io_ready(io_ready),
        .pc_en(pc_en),
        .pc_load(pc_load),
        .rf_we(rf_we),
        .mem_we(mem_we),
        .io_rd(io_rd),
        .io_wr(io_wr),
        .flags_we(flags_we),
        .wb_sel(wb_sel),
        .halted(halted),
        .retire(retire)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    initial begin
        errors = 0;
        opcode = 4'h0;
        cond = 3'b000;
        flags = 4'b0000;
        io_ready = 1'b1;

        // Reset check
        rst_n = 1'b0;
        @(posedge clk);
        @(posedge clk);
        rst_n = 1'b1;
        #1;
        if (halted !== 1'b0 || retire !== 1'b0) begin
            $display("ERROR: Control unit reset signals incorrect");
            errors = errors + 1;
        end

        // Check LDI (0x1): rf_we=1, wb_sel=2'b10
        opcode = 4'h1;
        @(posedge clk);
        #1;
        if (rf_we !== 1'b1 || wb_sel !== 2'b10 || retire !== 1'b1) begin
            $display("ERROR: LDI control signals incorrect");
            errors = errors + 1;
        end

        // Check ADD (0x4): rf_we=1, flags_we=1, wb_sel=2'b00
        opcode = 4'h4;
        @(posedge clk);
        #1;
        if (rf_we !== 1'b1 || flags_we !== 1'b1 || wb_sel !== 2'b00) begin
            $display("ERROR: ADD control signals incorrect");
            errors = errors + 1;
        end

        // Check ST (0x3): mem_we=1, rf_we=0
        opcode = 4'h3;
        @(posedge clk);
        #1;
        if (mem_we !== 1'b1 || rf_we !== 1'b0) begin
            $display("ERROR: ST control signals incorrect");
            errors = errors + 1;
        end

        // Check JMP (0xC): pc_load=1
        opcode = 4'hC;
        @(posedge clk);
        #1;
        if (pc_load !== 1'b1) begin
            $display("ERROR: JMP pc_load expected 1");
            errors = errors + 1;
        end

        // Check Branch BEQ (0xD, cond=0b000) with Z=1 (flags[3]=1)
        opcode = 4'hD;
        cond = 3'b000;
        flags = 4'b1000; // Z=1
        @(posedge clk);
        #1;
        if (pc_load !== 1'b1) begin
            $display("ERROR: BEQ taken pc_load expected 1");
            errors = errors + 1;
        end

        // Check HLT (0xF): halted=1
        opcode = 4'hF;
        @(posedge clk);
        #1;
        if (halted !== 1'b1) begin
            $display("ERROR: HLT expected halted = 1");
            errors = errors + 1;
        end

        if (errors == 0) begin
            $display("TESTBENCH: PASS");
        end else begin
            $display("TESTBENCH: FAIL (%0d errors)", errors);
        end
        $finish;
    end

endmodule
