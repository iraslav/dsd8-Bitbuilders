// tb_prog_counter.v -- self-checking unit testbench for prog_counter
`timescale 1ns/1ps

module tb_prog_counter;

    reg        clk;
    reg        rst_n;
    reg        pc_en;
    reg        pc_load;
    reg  [8:0] branch_addr;
    wire [8:0] pc;

    integer errors;

    prog_counter dut (
        .clk(clk),
        .rst_n(rst_n),
        .pc_en(pc_en),
        .pc_load(pc_load),
        .branch_addr(branch_addr),
        .pc(pc)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    initial begin
        errors = 0;
        pc_en = 1'b0;
        pc_load = 1'b0;
        branch_addr = 9'h000;

        // Reset test
        rst_n = 1'b0;
        @(negedge clk);
        @(negedge clk);
        rst_n = 1'b1;
        @(negedge clk);
        if (pc !== 9'h000) begin
            $display("ERROR: PC after reset expected 000, got %h", pc);
            errors = errors + 1;
        end

        // Increment test
        pc_en = 1'b1;
        pc_load = 1'b0;
        @(negedge clk);
        if (pc !== 9'h001) begin
            $display("ERROR: PC increment expected 001, got %h", pc);
            errors = errors + 1;
        end

        @(negedge clk);
        if (pc !== 9'h002) begin
            $display("ERROR: PC increment expected 002, got %h", pc);
            errors = errors + 1;
        end

        // Hold test (pc_en = 0)
        pc_en = 1'b0;
        @(negedge clk);
        if (pc !== 9'h002) begin
            $display("ERROR: PC hold expected 002, got %h", pc);
            errors = errors + 1;
        end

        // Branch load test
        pc_en = 1'b1;
        pc_load = 1'b1;
        branch_addr = 9'h1A5;
        @(negedge clk);
        if (pc !== 9'h1A5) begin
            $display("ERROR: PC load expected 1A5, got %h", pc);
            errors = errors + 1;
        end

        // Wraparound test from 0x1FF to 0x000
        branch_addr = 9'h1FF;
        @(negedge clk);
        pc_load = 1'b0;
        @(negedge clk);
        if (pc !== 9'h000) begin
            $display("ERROR: PC wraparound expected 000, got %h", pc);
            errors = errors + 1;
        end

        if (errors == 0) begin
            $display("TESTBENCH: PASS");
        end else begin
            $display("TESTBENCH: FAIL (%0d errors)", errors);
        end
        $finish;
    end

endmodule
