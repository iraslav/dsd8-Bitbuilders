// tb_instr_decoder.v -- self-checking unit testbench for instr_decoder
`timescale 1ns/1ps

module tb_instr_decoder;

    reg  [15:0] instr;
    wire [3:0]  opcode;
    wire [2:0]  rd;
    wire [2:0]  rs1;
    wire [2:0]  rs2;
    wire [7:0]  imm8;
    wire [8:0]  addr9;
    wire [2:0]  cond;
    wire [7:0]  port;
    wire        io_dir;

    integer errors;

    instr_decoder dut (
        .instr(instr),
        .opcode(opcode),
        .rd(rd),
        .rs1(rs1),
        .rs2(rs2),
        .imm8(imm8),
        .addr9(addr9),
        .cond(cond),
        .port(port),
        .io_dir(io_dir)
    );

    initial begin
        errors = 0;

        // Test vector 1: 0x1401 (LDI R2, 1)
        instr = 16'h1401;
        #1;
        if (opcode !== 4'h1 || rd !== 3'h2 || imm8 !== 8'h01) begin
            $display("ERROR: 1401 decode failed");
            errors = errors + 1;
        end

        // Test vector 2: 0x4DA0 (ADD R6, R6, R4) -> opcode=4, rd=6, rs1=6, rs2=4
        instr = 16'h4DA0; // 0100 1101 1010 0000
        #1;
        if (opcode !== 4'h4 || rd !== 3'h6 || rs1 !== 3'h6 || rs2 !== 3'h4) begin
            $display("ERROR: 4DA0 decode failed");
            errors = errors + 1;
        end

        // Test vector 3: 0xE302 (OUT 0x02, R1) -> opcode=0xE, rs=1 (rd bits), io_dir=1, port=0x02
        instr = 16'hE302;
        #1;
        if (opcode !== 4'hE || rd !== 3'h1 || io_dir !== 1'b1 || port !== 8'h02) begin
            $display("ERROR: E302 decode failed");
            errors = errors + 1;
        end

        // Test vector 4: 0xD205 (BNE 0x005) -> opcode=0xD, cond=1, addr9=0x005
        instr = 16'hD205;
        #1;
        if (opcode !== 4'hD || cond !== 3'b001 || addr9 !== 9'h005) begin
            $display("ERROR: D205 decode failed");
            errors = errors + 1;
        end

        if (errors == 0) begin
            $display("TESTBENCH: PASS");
        end else begin
            $display("TESTBENCH: FAIL (%0d errors)", errors);
        end
        $finish;
    end

endmodule
