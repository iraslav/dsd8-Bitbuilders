// tb_register_file.v -- self-checking unit testbench for register_file
`timescale 1ns/1ps

module tb_register_file;

    reg        clk;
    reg        rst_n;
    reg  [2:0] ra1;
    reg  [2:0] ra2;
    wire [7:0] rd1;
    wire [7:0] rd2;
    reg        we;
    reg  [2:0] wa;
    reg  [7:0] wd;

    integer errors;
    integer i;

    register_file dut (
        .clk(clk),
        .rst_n(rst_n),
        .ra1(ra1),
        .ra2(ra2),
        .rd1(rd1),
        .rd2(rd2),
        .we(we),
        .wa(wa),
        .wd(wd)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    initial begin
        errors = 0;
        we = 1'b0;
        wa = 3'b000;
        wd = 8'h00;
        ra1 = 3'b000;
        ra2 = 3'b000;

        // Reset check: all registers must be 0x00
        rst_n = 1'b0;
        @(negedge clk);
        @(negedge clk);
        rst_n = 1'b1;
        #1;
        for (i = 0; i < 8; i = i + 1) begin
            ra1 = i;
            #1;
            if (rd1 !== 8'h00) begin
                $display("ERROR: Register R%0d after reset expected 00, got %h", i, rd1);
                errors = errors + 1;
            end
        end

        // Write unique values to R0..R7 on negedge clk
        for (i = 0; i < 8; i = i + 1) begin
            @(negedge clk);
            we = 1'b1;
            wa = i;
            wd = 8'h10 + i;
        end
        @(negedge clk);
        we = 1'b0;

        // Verify values via both read ports
        for (i = 0; i < 8; i = i + 1) begin
            ra1 = i;
            ra2 = 7 - i;
            #1;
            if (rd1 !== (8'h10 + i)) begin
                $display("ERROR: Read port 1 R%0d expected %h, got %h", i, 8'h10 + i, rd1);
                errors = errors + 1;
            end
            if (rd2 !== (8'h10 + (7 - i))) begin
                $display("ERROR: Read port 2 R%0d expected %h, got %h", 7 - i, 8'h10 + (7 - i), rd2);
                errors = errors + 1;
            end
        end

        // Test R14 requirement: same-cycle read and write returns OLD value
        @(negedge clk);
        ra1 = 3'b010; // R2 currently holds 0x12
        wa  = 3'b010;
        wd  = 8'hAA;
        we  = 1'b1;
        #1;
        if (rd1 !== 8'h12) begin
            $display("ERROR: Combinational read before edge expected old value 12, got %h", rd1);
            errors = errors + 1;
        end

        @(posedge clk);
        #1;
        // After posedge clk, the new value is stored
        if (rd1 !== 8'hAA) begin
            $display("ERROR: Read after edge expected new value AA, got %h", rd1);
            errors = errors + 1;
        end

        if (errors == 0) begin
            $display("TESTBENCH: PASS");
        end else begin
            $display("TESTBENCH: FAIL (%0d errors)", errors);
        end
        $finish;
    end

endmodule
