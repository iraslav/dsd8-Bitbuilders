// tb_flags_reg.v -- self-checking unit testbench for flags_reg
`timescale 1ns/1ps

module tb_flags_reg;

    reg        clk;
    reg        rst_n;
    reg        flags_we;
    reg  [3:0] flags_in;
    wire [3:0] flags_out;

    integer errors;

    flags_reg dut (
        .clk(clk),
        .rst_n(rst_n),
        .flags_we(flags_we),
        .flags_in(flags_in),
        .flags_out(flags_out)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    initial begin
        errors = 0;
        flags_we = 1'b0;
        flags_in = 4'b0000;

        // Reset check
        rst_n = 1'b0;
        @(posedge clk);
        @(posedge clk);
        rst_n = 1'b1;
        #1;
        if (flags_out !== 4'b0000) begin
            $display("ERROR: Flags after reset expected 0000, got %b", flags_out);
            errors = errors + 1;
        end

        // Write enable test: update to {Z=1, N=0, C=1, V=0} = 4'b1010
        flags_we = 1'b1;
        flags_in = 4'b1010;
        @(posedge clk);
        #1;
        if (flags_out !== 4'b1010) begin
            $display("ERROR: Flags update expected 1010, got %b", flags_out);
            errors = errors + 1;
        end

        // Hold test: flags_we = 0 should preserve value
        flags_we = 1'b0;
        flags_in = 4'b0101;
        @(posedge clk);
        #1;
        if (flags_out !== 4'b1010) begin
            $display("ERROR: Flags hold expected 1010, got %b", flags_out);
            errors = errors + 1;
        end

        if (errors == 0) begin
            $display("TESTBENCH: PASS");
        end else begin
            $display("TESTBENCH: FAIL (%0d errors)", errors);
        end
        $finish;
    end

endmodule
