// tb_watchdog_timer.v -- Comprehensive Self-Checking Unit Testbench for Watchdog Timer
//
// Verifies all 15 required features:
//   1. Reset condition
//   2. Watchdog enable and disable
//   3. Correct reload value
//   4. Prescaler functionality
//   5. Exact timeout cycle count: (RELOAD + 1) * (PRESCALE + 1)
//   6. Correct kick operation (key 0xA5)
//   7. Invalid kick keys ignored
//   8. Kick postpones expiry
//   9. Sticky expired flag
//  10. Clearing expired flag
//  11. Disabled watchdog does not count
//  12. Reset request pulse (1-cycle pulse when enabled)
//  13. Counter readback
//  14. Kick and expiry in the same cycle (kick priority)
//  15. Randomized RELOAD and PRESCALE values verification

`timescale 1ns/1ps

`ifndef WATCHDOG_TIMER_V
`include "../rtl/watchdog_timer.v"
`endif

module tb_watchdog_timer;

    reg        clk;
    reg        rst_n;
    reg  [7:0] io_port;
    reg  [7:0] io_wdata;
    wire [7:0] io_rdata;
    reg        io_rd;
    reg        io_wr;
    wire       io_ready;
    wire       expired;
    wire       reset_req;

    integer errors = 0;
    integer cycle_counter = 0;

    // Instantiate DUT
    watchdog_timer dut (
        .clk       (clk),
        .rst_n     (rst_n),
        .io_port   (io_port),
        .io_wdata  (io_wdata),
        .io_rdata  (io_rdata),
        .io_rd     (io_rd),
        .io_wr     (io_wr),
        .io_ready  (io_ready),
        .expired   (expired),
        .reset_req (reset_req)
    );

    // Clock generator: 10ns period (100 MHz)
    initial clk = 1'b0;
    always #5 clk = ~clk;

    // Helper tasks for IO operations
    task write_reg(input [7:0] port, input [7:0] data);
        begin
            @(posedge clk);
            io_port  <= port;
            io_wdata <= data;
            io_wr    <= 1'b1;
            io_rd    <= 1'b0;
            @(posedge clk);
            #1;
            io_wr    <= 1'b0;
            io_port  <= 8'h00;
            io_wdata <= 8'h00;
        end
    endtask

    task read_reg(input [7:0] port, output [7:0] data);
        begin
            @(posedge clk);
            io_port <= port;
            io_rd   <= 1'b1;
            io_wr   <= 1'b0;
            #1;
            data    = io_rdata;
            @(posedge clk);
            #1;
            io_rd   <= 1'b0;
            io_port <= 8'h00;
        end
    endtask

    task assert_val(input [7:0] actual, input [7:0] expected, input [127:0] msg);
        begin
            if (actual !== expected) begin
                $display("  [FAIL] %0s: expected 0x%02X, got 0x%02X at time %0t", msg, expected, actual, $time);
                errors = errors + 1;
            end
        end
    endtask

    reg [7:0] rdata;
    integer i, k;
    integer rnd_reload, rnd_presc, expected_cycles, elapsed_cycles;

    initial begin
        $display("==================================================");
        $display(" Starting Watchdog Timer Self-Checking Testbench  ");
        $display("==================================================");
        rst_n    = 1'b0;
        io_port  = 8'h00;
        io_wdata = 8'h00;
        io_rd    = 1'b0;
        io_wr    = 1'b0;

        repeat (4) @(posedge clk);
        rst_n = 1'b1;
        @(posedge clk);
        #1;

        // -------------------------------------------------------------
        // Test 1: Reset Condition
        // -------------------------------------------------------------
        read_reg(8'h50, rdata);
        assert_val(rdata, 8'h00, "Reset WD_CTRL");
        read_reg(8'h54, rdata);
        assert_val(rdata, 8'h00, "Reset WD_STATUS");
        assert_val(expired, 1'b0, "Reset expired signal");
        assert_val(reset_req, 1'b0, "Reset reset_req signal");
        $display("  [OK] Test 1: Reset condition verified");

        // -------------------------------------------------------------
        // Test 2: Enable and Disable
        // -------------------------------------------------------------
        write_reg(8'h50, 8'h01); // Enable watchdog
        read_reg(8'h50, rdata);
        assert_val(rdata, 8'h01, "Enable WD_CTRL");
        read_reg(8'h54, rdata);
        assert_val(rdata[1], 1'b1, "WD_STATUS enable bit");

        write_reg(8'h50, 8'h00); // Disable watchdog
        read_reg(8'h50, rdata);
        assert_val(rdata, 8'h00, "Disable WD_CTRL");
        read_reg(8'h54, rdata);
        assert_val(rdata[1], 1'b0, "WD_STATUS enable bit after disable");
        $display("  [OK] Test 2: Enable and disable functionality verified");

        // -------------------------------------------------------------
        // Test 3: Correct Reload Value
        // -------------------------------------------------------------
        write_reg(8'h51, 8'h0A); // Set reload to 10
        read_reg(8'h51, rdata);
        assert_val(rdata, 8'h0A, "Readback WD_RELOAD");
        read_reg(8'h55, rdata);
        assert_val(rdata, 8'h0A, "Preset WD_COUNT when disabled");
        $display("  [OK] Test 3: Reload register and counter presetting verified");

        // -------------------------------------------------------------
        // Test 4: Prescaler Functionality & Counter Readback (Test 13)
        // -------------------------------------------------------------
        write_reg(8'h51, 8'h05); // reload = 5
        write_reg(8'h52, 8'h02); // presc = 2 (each tick takes 3 cycles)
        read_reg(8'h52, rdata);
        assert_val(rdata, 8'h02, "Readback WD_PRESC");
        $display("  [OK] Test 4: Prescaler register access verified");

        // -------------------------------------------------------------
        // Test 5: Exact Timeout Cycle Count
        // Formula: (RELOAD + 1) * (PRESCALE + 1)
        // For RELOAD=3, PRESCALE=1 -> (3+1)*(1+1) = 8 cycles.
        // -------------------------------------------------------------
        write_reg(8'h50, 8'h00); // disable
        write_reg(8'h54, 8'h00); // clear any expired
        write_reg(8'h51, 8'h03); // RELOAD = 3
        write_reg(8'h52, 8'h01); // PRESCALE = 1

        @(posedge clk);
        io_port  <= 8'h50;
        io_wdata <= 8'h01; // Enable, no reset_req
        io_wr    <= 1'b1;
        @(posedge clk);
        #1;
        io_wr    <= 1'b0;
        io_port  <= 8'h00;

        cycle_counter = 0;
        while (!expired && cycle_counter < 50) begin
            @(posedge clk);
            #1;
            cycle_counter = cycle_counter + 1;
        end
        assert_val(cycle_counter[7:0], 8'd8, "Exact timeout cycles (3+1)*(1+1)=8");
        assert_val(expired, 1'b1, "Expired asserted after 8 cycles");
        $display("  [OK] Test 5: Exact timeout count = 8 cycles verified ((3+1)*(1+1))");

        // -------------------------------------------------------------
        // Test 9: Sticky Expired Flag
        // -------------------------------------------------------------
        repeat (10) @(posedge clk);
        assert_val(expired, 1'b1, "Expired flag remains sticky HIGH");
        $display("  [OK] Test 9: Sticky expired flag persists across cycles");

        // -------------------------------------------------------------
        // Test 10: Clearing Expired Flag
        // -------------------------------------------------------------
        write_reg(8'h50, 8'h00); // Disable watchdog first
        write_reg(8'h54, 8'h00); // Clear status
        assert_val(expired, 1'b0, "Expired cleared by writing WD_STATUS");
        read_reg(8'h54, rdata);
        assert_val(rdata[0], 1'b0, "WD_STATUS[0] reads 0 after clear");
        $display("  [OK] Test 10: Clearing expired flag via WD_STATUS write verified");

        // -------------------------------------------------------------
        // Test 11: Disabled Watchdog Does Not Count
        // -------------------------------------------------------------
        write_reg(8'h50, 8'h00); // Disable
        write_reg(8'h54, 8'h00); // Ensure clear
        write_reg(8'h51, 8'h02); // reload = 2
        write_reg(8'h52, 8'h00); // presc = 0
        repeat (20) @(posedge clk);
        assert_val(expired, 1'b0, "Disabled watchdog never expires");
        read_reg(8'h55, rdata);
        assert_val(rdata, 8'h02, "Counter remains frozen while disabled");
        $display("  [OK] Test 11: Disabled watchdog remains frozen and never expires");

        // -------------------------------------------------------------
        // Test 6 & 8: Correct Kick Operation Postpones Expiry
        // -------------------------------------------------------------
        write_reg(8'h50, 8'h00); // Disable
        write_reg(8'h54, 8'h00); // Clear
        write_reg(8'h51, 8'h05); // reload = 5
        write_reg(8'h52, 8'h01); // presc = 1 (timeout = 6*2 = 12 cycles)
        write_reg(8'h50, 8'h01); // Enable

        for (k = 0; k < 4; k = k + 1) begin
            repeat (6) @(posedge clk);
            write_reg(8'h53, 8'hA5); // Valid kick key
            assert_val(expired, 1'b0, "Watchdog does not expire when kicked regularly");
        end
        $display("  [OK] Test 6 & 8: Periodic kicks (0xA5) successfully postpone expiry");

        // -------------------------------------------------------------
        // Test 7: Invalid Kick Keys Are Ignored
        // -------------------------------------------------------------
        write_reg(8'h50, 8'h00); // Disable
        write_reg(8'h54, 8'h00); // Clear expired
        write_reg(8'h51, 8'h02); // reload = 2
        write_reg(8'h52, 8'h00); // presc = 0 (timeout = 3 cycles)
        write_reg(8'h50, 8'h01); // Enable

        write_reg(8'h53, 8'h00); // wrong key
        write_reg(8'h53, 8'h55); // wrong key
        write_reg(8'h53, 8'hFF); // wrong key
        repeat (10) @(posedge clk);
        assert_val(expired, 1'b1, "Expired because invalid kicks were ignored");
        $display("  [OK] Test 7: Invalid kick keys correctly rejected");

        // -------------------------------------------------------------
        // Test 12: Reset Request Pulse (1-cycle pulse when enabled)
        // -------------------------------------------------------------
        write_reg(8'h50, 8'h00); // Disable
        write_reg(8'h54, 8'h00); // Clear
        write_reg(8'h51, 8'h01); // reload = 1
        write_reg(8'h52, 8'h00); // presc = 0 (timeout = 2 cycles)

        write_reg(8'h50, 8'h03); // Enable WITH reset-on-expiry
        cycle_counter = 0;
        while (!reset_req && cycle_counter < 20) begin
            @(posedge clk);
            #1;
            cycle_counter = cycle_counter + 1;
        end
        assert_val(reset_req, 1'b1, "Reset request pulsed HIGH on timeout");
        @(posedge clk);
        #1;
        assert_val(reset_req, 1'b0, "Reset request returned to 0 after 1 cycle");
        $display("  [OK] Test 12: Reset request generated as exact 1-cycle pulse");

        // -------------------------------------------------------------
        // Test 13: Counter Readback
        // -------------------------------------------------------------
        write_reg(8'h50, 8'h00); // Disable
        write_reg(8'h51, 8'h0E); // reload = 14
        read_reg(8'h55, rdata);
        assert_val(rdata, 8'h0E, "Counter live readback");
        $display("  [OK] Test 13: Live counter readback at 0x55 verified");

        // -------------------------------------------------------------
        // Test 14: Kick and Expiry in the Same Clock Cycle (Kick Priority)
        // -------------------------------------------------------------
        write_reg(8'h50, 8'h00); // Disable
        write_reg(8'h54, 8'h00); // Clear
        write_reg(8'h51, 8'h02); // reload = 2
        write_reg(8'h52, 8'h00); // presc = 0 -> timeout in 3 cycles
        write_reg(8'h50, 8'h01); // Enable

        @(posedge clk);
        @(posedge clk);

        // Apply kick exactly on 3rd cycle where expiry would occur
        io_port  <= 8'h53;
        io_wdata <= 8'hA5;
        io_wr    <= 1'b1;
        @(posedge clk);
        #1;
        io_wr    <= 1'b0;
        io_port  <= 8'h00;

        assert_val(expired, 1'b0, "Kick priority prevented timeout in simultaneous cycle");
        assert_val(dut.down_count, 8'h02, "Counter was reloaded to 2 by kick");
        $display("  [OK] Test 14: Simultaneous kick & expiry priority rule verified");

        // -------------------------------------------------------------
        // Test 15: Randomized RELOAD and PRESCALE Values
        // -------------------------------------------------------------
        for (i = 0; i < 20; i = i + 1) begin
            rnd_reload = (i * 3 + 1) % 7 + 1; // 1 .. 7
            rnd_presc  = (i * 5 + 2) % 4;     // 0 .. 3
            expected_cycles = (rnd_reload + 1) * (rnd_presc + 1);

            write_reg(8'h50, 8'h00); // Disable
            write_reg(8'h54, 8'h00); // Clear
            write_reg(8'h51, rnd_reload[7:0]);
            write_reg(8'h52, rnd_presc[7:0]);

            @(posedge clk);
            io_port  <= 8'h50;
            io_wdata <= 8'h01;
            io_wr    <= 1'b1;
            @(posedge clk);
            #1;
            io_wr    <= 1'b0;
            io_port  <= 8'h00;

            elapsed_cycles = 0;
            while (!expired && elapsed_cycles < 200) begin
                @(posedge clk);
                #1;
                elapsed_cycles = elapsed_cycles + 1;
            end

            if (elapsed_cycles !== expected_cycles) begin
                $display("  [FAIL] Randomized test %0d: reload=%0d presc=%0d expected=%0d got=%0d",
                         i, rnd_reload, rnd_presc, expected_cycles, elapsed_cycles);
                errors = errors + 1;
            end
        end
        $display("  [OK] Test 15: 20 randomized reload & prescaler test cases passed");

        // -------------------------------------------------------------
        // Summary & Result Reporting
        // -------------------------------------------------------------
        $display("--------------------------------------------------");
        if (errors == 0) begin
            $display("TESTBENCH: PASS");
        end else begin
            $display("TESTBENCH: FAIL (%0d errors)", errors);
        end
        $display("--------------------------------------------------");
        $finish;
    end

endmodule
