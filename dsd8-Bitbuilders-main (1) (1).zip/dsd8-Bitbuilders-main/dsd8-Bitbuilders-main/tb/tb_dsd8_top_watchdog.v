// tb_dsd8_top_watchdog.v -- End-to-end Top-Level System Testbench for Watchdog
//
// Verifies full system integration:
//   - Instantiates dsd8_top (CPU + Memory + IO Bus + Watchdog + Peripherals)
//   - Verifies that watchdog expired output directly drives leds[7] in hardware
//   - Verifies normal execution with periodic kicks keeps leds[7] OFF
//   - Verifies CPU deadlock/hang simulation causes timeout and turns leds[7] ON
//   - Verifies reset-on-expiry pulls CPU reset and resets program execution

`timescale 1ns/1ps

`ifndef DSD8_TOP_V
`include "../rtl/watchdog_timer.v"
`include "../rtl/io_bus.v"
`include "../rtl/instr_memory.v"
`include "../rtl/dsd8_cpu.v"
`include "../rtl/dsd8_top.v"
`endif

module tb_dsd8_top_watchdog;

    reg        clk;
    reg        rst_n;
    reg  [7:0] switches;
    reg  [4:0] buttons;
    wire [7:0] leds;
    wire [6:0] seg;
    wire [3:0] an;
    wire       halted;

    integer errors = 0;
    integer step_cnt = 0;

    // Instantiate Top-level System
    dsd8_top top_dut (
        .clk      (clk),
        .rst_n    (rst_n),
        .switches (switches),
        .buttons  (buttons),
        .leds     (leds),
        .seg      (seg),
        .an       (an),
        .halted   (halted)
    );

    // Clock generator: 100MHz (10ns period)
    initial clk = 1'b0;
    always #5 clk = ~clk;

    task check_condition(input condition, input [127:0] desc);
        begin
            if (!condition) begin
                $display("  [FAIL] %0s at time %0t", desc, $time);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        $display("==================================================");
        $display(" Starting End-to-End dsd8_top Watchdog System Test");
        $display("==================================================");
        rst_n    = 1'b0;
        switches = 8'h00;
        buttons  = 5'h00;

        // -------------------------------------------------------------
        // Demo 1: Normal Kick Execution
        // Preload instruction memory with normal kick program:
        // 0: LDI R4, 10    -> 0x180A
        // 1: OUT 0x51, R4  -> 0xE951  (WD_RELOAD = 10)
        // 2: LDI R4, 2     -> 0x1802
        // 3: OUT 0x52, R4  -> 0xE952  (WD_PRESC = 2)
        // 4: LDI R4, 1     -> 0x1801
        // 5: OUT 0x50, R4  -> 0xE950  (WD_CTRL = 1, enable)
        // 6: LDI R3, 0xA5  -> 0x16A5  (Kick key)
        // 7: OUT 0x53, R3  -> 0xE753  (Kick 1)
        // 8: OUT 0x53, R3  -> 0xE753  (Kick 2)
        // 9: OUT 0x53, R3  -> 0xE753  (Kick 3)
        // 10: HLT          -> 0xF000
        // -------------------------------------------------------------
        top_dut.imem.mem[0]  = 16'h180A;
        top_dut.imem.mem[1]  = 16'hE951;
        top_dut.imem.mem[2]  = 16'h1802;
        top_dut.imem.mem[3]  = 16'hE952;
        top_dut.imem.mem[4]  = 16'h1801;
        top_dut.imem.mem[5]  = 16'hE950;
        top_dut.imem.mem[6]  = 16'h16A5;
        top_dut.imem.mem[7]  = 16'hE753;
        top_dut.imem.mem[8]  = 16'hE753;
        top_dut.imem.mem[9]  = 16'hE753;
        top_dut.imem.mem[10] = 16'hF000;

        repeat (4) @(posedge clk);
        rst_n = 1'b1;

        step_cnt = 0;
        while (!halted && step_cnt < 200) begin
            @(posedge clk);
            step_cnt = step_cnt + 1;
        end

        #1;
        check_condition(leds[7] == 1'b0, "Normal program: LED 7 must be OFF (no timeout)");
        $display("  [OK] System Stage 1: Normal periodic kicks keep LED 7 OFF");

        // -------------------------------------------------------------
        // Demo 2: CPU Hang Simulation
        // Reload program where CPU enables watchdog, kicks once, then enters infinite loop
        // 0: LDI R4, 2     -> 0x1802  (RELOAD = 2)
        // 1: OUT 0x51, R4  -> 0xE951
        // 2: LDI R4, 1     -> 0x1801  (PRESCALE = 1, timeout = 3*2 = 6 cycles)
        // 3: OUT 0x52, R4  -> 0xE952
        // 4: LDI R4, 1     -> 0x1801  (CTRL = 1)
        // 5: OUT 0x50, R4  -> 0xE950
        // 6: JMP 0x006     -> 0xC006  (Hang: infinite jump to self without kicking!)
        // -------------------------------------------------------------
        rst_n = 1'b0;
        top_dut.imem.mem[0] = 16'h1802;
        top_dut.imem.mem[1] = 16'hE951;
        top_dut.imem.mem[2] = 16'h1801;
        top_dut.imem.mem[3] = 16'hE952;
        top_dut.imem.mem[4] = 16'h1801;
        top_dut.imem.mem[5] = 16'hE950;
        top_dut.imem.mem[6] = 16'hC006;

        repeat (4) @(posedge clk);
        rst_n = 1'b1;

        // Run CPU in hang loop for 30 cycles (well past 6-cycle timeout)
        repeat (30) @(posedge clk);
        #1;
        check_condition(leds[7] == 1'b1, "Hang simulation: LED 7 must be ON (expired)");
        check_condition(top_dut.wd_expired == 1'b1, "Top wd_expired must be HIGH");
        $display("  [OK] System Stage 2: CPU deadlock simulation triggers timeout & illuminates LED 7");

        // -------------------------------------------------------------
        // Demo 3: Reset on Expiry
        // -------------------------------------------------------------
        rst_n = 1'b0;
        top_dut.imem.mem[4] = 16'h1803; // CTRL = 3 (bit 1=1: reset-on-expiry)
        repeat (4) @(posedge clk);
        rst_n = 1'b1;

        step_cnt = 0;
        while (!top_dut.wd_reset_req && step_cnt < 50) begin
            @(posedge clk);
            #1;
            step_cnt = step_cnt + 1;
        end
        #1;
        check_condition(top_dut.wd_reset_req == 1'b1, "wd_reset_req pulsed on expiry");
        check_condition(top_dut.cpu_rst_n == 1'b0, "CPU reset was asserted by watchdog");

        @(posedge clk);
        #1;
        check_condition(top_dut.cpu.pc == 9'h000, "CPU PC reset back to 0x000");
        $display("  [OK] System Stage 3: Reset-on-expiry resets CPU core back to PC = 0x000");

        // -------------------------------------------------------------
        // Summary & Result Reporting
        // -------------------------------------------------------------
        $display("--------------------------------------------------");
        if (errors == 0) begin
            $display("TESTBENCH: PASS");
        end else begin
            $display("TESTBENCH: FAIL (%0d errors)", errors);
        end
        $display("--------------------------------------------------");
        $finish;
    end

endmodule
