@echo off
setlocal
python scripts\view_waveform.py %*
endlocal
