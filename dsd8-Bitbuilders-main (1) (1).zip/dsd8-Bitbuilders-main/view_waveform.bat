@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
if exist "%SCRIPT_DIR%dsd8-Bitbuilders-main\scripts\view_waveform.py" (
    cd /d "%SCRIPT_DIR%dsd8-Bitbuilders-main"
)
python scripts\view_waveform.py %*
endlocal
