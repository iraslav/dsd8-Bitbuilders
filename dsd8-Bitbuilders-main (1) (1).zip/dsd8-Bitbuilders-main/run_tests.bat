@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
if exist "%SCRIPT_DIR%dsd8-Bitbuilders-main\scripts\run_conformance.py" (
    cd /d "%SCRIPT_DIR%dsd8-Bitbuilders-main"
)

echo =======================================================
echo Running DSD-8 Unit Tests...
echo =======================================================
python scripts\run_unit_tests.py
if errorlevel 1 goto error

echo.
echo =======================================================
echo Running DSD-8 Conformance Tests...
echo =======================================================
python scripts\run_conformance.py
if errorlevel 1 goto error

echo.
echo [SUCCESS] All unit tests and conformance tests passed!
goto end

:error
echo.
echo [FAILED] Some tests did not pass.
exit /b 1

:end
endlocal
